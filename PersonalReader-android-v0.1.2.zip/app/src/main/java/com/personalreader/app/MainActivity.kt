package com.personalreader.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    private lateinit var repo: BookRepository
    private var refreshLibrary by mutableStateOf(0)

    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            repo.import(uri)
        }
        refreshLibrary++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = BookRepository(this)
        setContent {
            MaterialTheme {
                val setupDone = remember { mutableStateOf(repo.setupDone) }
                if (!setupDone.value) {
                    SetupScreen(onFinish = { eink -> repo.setEink(eink); repo.setupDone = true; setupDone.value = true })
                } else {
                    AppScreen(repo = repo, refreshKey = refreshLibrary, onImport = { importLauncher.launch(arrayOf("application/epub+zip", "application/zip")) })
                }
            }
        }
    }
}

data class Book(
    val id: String,
    val title: String,
    val author: String,
    val path: String,
    val progress: Float = 0f
)

class BookRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("reader", Context.MODE_PRIVATE)
    private val booksDir = File(context.filesDir, "books").also { it.mkdirs() }
    var setupDone: Boolean
        get() = prefs.getBoolean("setup_done", false)
        set(value) { prefs.edit().putBoolean("setup_done", value).apply() }
    val eink: Boolean get() = prefs.getBoolean("eink", false)
    fun setEink(v: Boolean) { prefs.edit().putBoolean("eink", v).apply() }

    fun books(): List<Book> = prefs.getStringSet("book_ids", emptySet()).orEmpty().mapNotNull { id ->
        val title = prefs.getString("book_${id}_title", null) ?: return@mapNotNull null
        Book(id, title, prefs.getString("book_${id}_author", "Unknown") ?: "Unknown", File(booksDir, "$id/book.epub").absolutePath, prefs.getFloat("book_${id}_progress", 0f))
    }.sortedBy { it.title.lowercase() }

    fun progress(id: String): Float = prefs.getFloat("book_${id}_progress", 0f)
    fun saveProgress(id: String, p: Float) = prefs.edit().putFloat("book_${id}_progress", p.coerceIn(0f,1f)).apply()

    fun import(uri: Uri) {
        val id = UUID.randomUUID().toString()
        val dest = File(booksDir, id).also { it.mkdirs() }
        val epub = File(dest, "book.epub")
        context.contentResolver.openInputStream(uri).use { input -> FileOutputStream(epub).use { output -> input!!.copyTo(output) } }
        val meta = Epub.extract(epub, dest)
        prefs.edit()
            .putStringSet("book_ids", (prefs.getStringSet("book_ids", emptySet()).orEmpty() + id))
            .putString("book_${id}_title", meta.title.ifBlank { epub.nameWithoutExtension })
            .putString("book_${id}_author", meta.author)
            .apply()
    }

    fun bookRoot(id: String) = File(booksDir, id)
}

data class EpubMeta(val title: String, val author: String, val language: String, val packagePath: String, val spine: List<String>)

object Epub {
    fun extract(epub: File, dest: File): EpubMeta {
        ZipInputStream(FileInputStream(epub)).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                if (!entry.isDirectory) {
                    val out = safeResolve(dest, entry.name) ?: continue
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
            }
        }
        val container = File(dest, "META-INF/container.xml")
        val packagePath = parseRootfile(container)
        val opf = File(dest, packagePath)
        return parseOpf(opf, packagePath)
    }

    private fun safeResolve(root: File, relative: String): File? {
        val f = File(root, relative)
        return if (f.canonicalPath.startsWith(root.canonicalPath + File.separator)) f else null
    }

    private fun parseRootfile(container: File): String {
        val p = android.util.Xml.newPullParser().apply { setInput(FileInputStream(container), "UTF-8") }
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG && p.name == "rootfile") return p.getAttributeValue(null, "full-path")
        }
        error("Invalid EPUB: container.xml has no rootfile")
    }

    private fun parseOpf(opf: File, packagePath: String): EpubMeta {
        val parser = android.util.Xml.newPullParser().apply { setInput(FileInputStream(opf), "UTF-8") }
        val base = opf.parentFile ?: opf
        val manifest = linkedMapOf<String, String>()
        val properties = linkedMapOf<String, String>()
        val spine = mutableListOf<String>()
        var title = ""
        var author = "Unknown"
        var language = ""
        while (parser.next() != XmlPullParser.END_DOCUMENT) {
            if (parser.eventType != XmlPullParser.START_TAG) continue
            when (parser.name.lowercase()) {
                "title" -> if (title.isBlank()) title = parser.readTextTrimmed()
                "creator" -> if (author == "Unknown") author = parser.readTextTrimmed()
                "language" -> if (language.isBlank()) language = parser.readTextTrimmed()
                "item" -> {
                    val id = parser.getAttributeValue(null, "id") ?: ""
                    val href = parser.getAttributeValue(null, "href") ?: ""
                    if (id.isNotBlank() && href.isNotBlank()) { manifest[id] = href; properties[id] = parser.getAttributeValue(null, "properties") ?: "" }
                }
                "itemref" -> parser.getAttributeValue(null, "idref")?.let { manifest[it]?.let { href -> spine += resolveRelative(opf, href) } }
            }
        }
        return EpubMeta(title, author, language, packagePath, spine)
    }

    private fun XmlPullParser.readTextTrimmed(): String {
        val text = nextText()
        return text.trim()
    }

    private fun resolveRelative(opf: File, href: String): String = File(opf.parentFile, href).normalize().relativeTo(opf.parentFile!!.parentFile!!).path

    fun buildBookHtml(root: File, meta: EpubMeta, fontSizeSp: Int, dark: Boolean, eink: Boolean): String {
        val body = StringBuilder()
        for (spinePath in meta.spine) {
            val file = File(root, spinePath)
            if (!file.exists()) continue
            var html = file.readText()
            html = html.replace(Regex("<head[^>]*>.*?</head>", RegexOption.DOT_MATCHES_ALL), "")
            html = html.replace(Regex("<script[^>]*>.*?</script>", RegexOption.DOT_MATCHES_ALL), "")
            val baseDir = file.parentFile!!.relativeTo(root).path.replace('\\', '/')
            html = rewriteResources(html, baseDir)
            body.append("<section class='chapter'>").append(html).append("</section>")
        }
        val bg = if (dark) "#111111" else "#F7F3EA"
        val fg = if (dark) "#E9E3D5" else "#24211C"
        val anim = if (eink) "none" else "smooth"
        return """
<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1.0,user-scalable=yes'>
<style>
*{box-sizing:border-box}html,body{margin:0;padding:0;background:$bg;color:$fg}
body{font-family:serif;font-size:${fontSizeSp}px;line-height:1.65;overflow-y:hidden;overflow-x:auto;scroll-behavior:$anim}
#book{height:100vh;column-width:100vw;column-gap:0;padding:34px 28px 56px 28px}
.chapter{break-before:column;break-inside:avoid}
img{max-width:100%;height:auto}a{color:inherit}p{text-align:justify;margin:.65em 0}h1,h2,h3{break-after:avoid}
${if (eink) "body{-webkit-font-smoothing:none;}" else ""}
</style></head><body><main id='book'>$body</main>
<script>
function pages(){return Math.max(1,Math.ceil(document.documentElement.scrollWidth/window.innerWidth));}
function page(){return Math.max(0,Math.round(window.scrollX/window.innerWidth));}
function gotoPage(p){window.scrollTo({left:p*window.innerWidth,top:0,behavior:'${if (eink) "auto" else "smooth"}'})}
function state(){return JSON.stringify({p:page(),pages:pages(),ratio:(page()+1)/pages()});}
</script></body></html>"""
    }

    private fun rewriteResources(html: String, baseDir: String): String {
        val attrRegex = Regex("((?:src|href)\\s*=\\s*['\"])(?!https?://|data:|#|file:|javascript:)([^'\"]+)(['\"])", RegexOption.IGNORE_CASE)
        return attrRegex.replace(html) { m ->
            val raw = m.groupValues[2]
            val normalized = if (raw.startsWith("/")) raw.removePrefix("/") else {
                val joined = if (baseDir.isBlank()) raw else "$baseDir/$raw"
                java.io.File(joined).normalize().path.replace('\\', '/')
            }
            m.groupValues[1] + normalized + m.groupValues[3]
        }
    }
}

@Composable
fun SetupScreen(onFinish: (Boolean) -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    var eink by remember { mutableStateOf(true) }
    Scaffold { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(28.dp), verticalArrangement = Arrangement.Center) {
            Text("Personal Reader", style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(12.dp))
            Text("Your private, offline reading space.", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(36.dp))
            when(step) {
                0 -> {
                    Text("Set it up once. Your library stays on this device.", style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(28.dp))
                    Button(onClick={step=1}, modifier=Modifier.fillMaxWidth()) { Text("Get started") }
                }
                1 -> {
                    Text("Device profile", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(10.dp))
                    Text("Enable E-Ink optimization to reduce animation and visual redraws.")
                    Spacer(Modifier.height(18.dp))
                    FilterChip(selected=eink, onClick={eink=!eink}, label={Text(if(eink) "E-Ink mode on" else "Standard mode")})
                    Spacer(Modifier.height(28.dp))
                    Button(onClick={onFinish(eink)}, modifier=Modifier.fillMaxWidth()) { Text("Finish setup") }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen(repo: BookRepository, refreshKey: Int, onImport: () -> Unit) {
    var selected by remember { mutableStateOf<Book?>(null) }
    var dark by remember { mutableStateOf(false) }
    var fontSize by remember { mutableIntStateOf(20) }
    var library by remember(refreshKey) { mutableStateOf(repo.books()) }
    if (selected == null) {
        Scaffold(topBar={ TopAppBar(title={Text("Personal Reader")}, actions={ TextButton(onClick=onImport){Text("Import EPUB")}; TextButton(onClick={dark=!dark}){Text(if(dark) "Light" else "Dark")} }) }) { pad ->
            LibraryView(library, onOpen={selected=it}, onImport=onImport, modifier=Modifier.padding(pad))
        }
    } else {
        ReaderScreen(book=selected!!, repo=repo, dark=dark, fontSize=fontSize, onFontSize={fontSize=it}, onBack={ selected=null; library=repo.books() })
    }
}

@Composable
fun LibraryView(books: List<Book>, onOpen: (Book)->Unit, onImport:()->Unit, modifier: Modifier) {
    Column(modifier.fillMaxSize()) {
        if (books.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("Your library is empty", style=MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(10.dp))
                    Text("Import an EPUB to begin reading.")
                    Spacer(Modifier.height(18.dp))
                    Button(onClick=onImport){Text("Import EPUB")}
                }
            }
        } else {
            LazyColumn(contentPadding=PaddingValues(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                items(books, key={it.id}) { book ->
                    Card(Modifier.fillMaxWidth().clickable{onOpen(book)}) {
                        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(54.dp).background(MaterialTheme.colorScheme.surfaceVariant))
                            Spacer(Modifier.size(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(book.title, style=MaterialTheme.typography.titleLarge)
                                Text(book.author, style=MaterialTheme.typography.bodyMedium)
                                Spacer(Modifier.height(8.dp))
                                Text("${(book.progress*100).toInt()}%")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReaderScreen(book: Book, repo: BookRepository, dark: Boolean, fontSize: Int, onFontSize: (Int)->Unit, onBack:()->Unit) {
    val context = LocalContext.current
    val root = repo.bookRoot(book.id)
    var page by remember { mutableIntStateOf((repo.progress(book.id)*1000).toInt()) }
    var total by remember { mutableIntStateOf(1000) }
    var menu by remember { mutableStateOf(false) }
    AndroidView(
        modifier=Modifier.fillMaxSize(),
        factory={ ctx ->
            WebView(ctx).apply {
                setBackgroundColor(Color.TRANSPARENT)
                settings.apply { javaScriptEnabled=true; domStorageEnabled=true; allowFileAccess=true; allowContentAccess=true; cacheMode=WebSettings.LOAD_NO_CACHE }
                webViewClient=WebViewClient()
                webChromeClient=WebChromeClient()
                setOnScrollChangeListener { _, _, _, _, _ ->
                    post {
                        evaluateJavascript("(page()+1)/pages()") { raw ->
                            val ratio = raw.toFloatOrNull()?.coerceIn(0f,1f) ?: 0f
                            page = (ratio * 1000).toInt()
                            total = 1000
                            repo.saveProgress(book.id, ratio)
                        }
                    }
                }
                val epubMetaFile = File(root, "META-INF/container.xml")
                val packagePath = readPackagePath(epubMetaFile)
                val meta = readMeta(File(root, packagePath), packagePath)
                val html = Epub.buildBookHtml(root, meta, fontSize, dark, repo.eink)
                loadDataWithBaseURL("file://${root.absolutePath}/", html, "text/html", "UTF-8", null)
                postDelayed({ evaluateJavascript("state()") { raw ->
                    val ratio = raw.substringAfter("ratio\\\":").substringBefore("}").toFloatOrNull() ?: 0f
                    post { scrollTo(0,0); page=(ratio*1000).toInt(); total=1000 }
                } }, 700)
            }
        },
        update={ web ->
            web.evaluateJavascript("document.documentElement.style.fontSize='${fontSize}px';"){}
        }
    )
    Box(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
            TextButton(onClick=onBack){Text("Back")}
            Spacer(Modifier.weight(1f))
            Text("${(repo.progress(book.id)*100).toInt()}%")
            TextButton(onClick={menu=!menu}){Text("Aa")}
        }
        AnimatedVisibility(menu, modifier=Modifier.align(Alignment.TopEnd).padding(top=58.dp,end=14.dp)) {
            Card { Column(Modifier.padding(14.dp)) {
                Text("Text size", style=MaterialTheme.typography.labelLarge)
                Row {
                    TextButton(onClick={onFontSize((fontSize-1).coerceAtLeast(12))}){Text("A-")}
                    TextButton(onClick={onFontSize((fontSize+1).coerceAtMost(32))}){Text("A+")}
                }
                TextButton(onClick={onBack}){Text("Close")}
            } }
        }
    }
}

private fun readPackagePath(container: File): String = run {
    val p = android.util.Xml.newPullParser().apply { setInput(FileInputStream(container), "UTF-8") }
    while(p.next()!=XmlPullParser.END_DOCUMENT) if(p.eventType==XmlPullParser.START_TAG && p.name=="rootfile") return@run p.getAttributeValue(null,"full-path")
    error("No rootfile")
}

private fun readMeta(opf: File, packagePath: String): EpubMeta {
    val parser = android.util.Xml.newPullParser().apply { setInput(FileInputStream(opf), "UTF-8") }
    val manifest=linkedMapOf<String,String>(); val spine=mutableListOf<String>(); var title=""; var author="Unknown"; var language=""
    while(parser.next()!=XmlPullParser.END_DOCUMENT) if(parser.eventType==XmlPullParser.START_TAG) when(parser.name.lowercase()){
        "title" -> if(title.isBlank()) title=parser.nextText().trim()
        "creator" -> if(author=="Unknown") author=parser.nextText().trim()
        "language" -> if(language.isBlank()) language=parser.nextText().trim()
        "item" -> { val id=parser.getAttributeValue(null,"id"); val href=parser.getAttributeValue(null,"href"); if(!id.isNullOrBlank()&&!href.isNullOrBlank()) manifest[id]=href }
        "itemref" -> parser.getAttributeValue(null,"idref")?.let{manifest[it]?.let{href->spine+=File(opf.parentFile,href).relativeTo(opf.parentFile!!.parentFile!!).path}}
    }
    return EpubMeta(title,author,language,packagePath,spine)
}
