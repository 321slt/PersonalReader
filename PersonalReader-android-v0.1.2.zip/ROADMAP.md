# Personal Reader roadmap

## Foundation already started
- Offline-first local EPUB library
- First-run setup wizard
- E-Ink profile
- EPUB extraction + OPF/spine discovery
- Reflowable chapter rendering
- Horizontal pagination
- Local progress
- Reader typography controls
- Light/dark reading themes
- Modular package layout for future feature work

## Next engineering pass
1. Replace the prototype WebView EPUB renderer with a production-grade EPUB engine.
2. Add reliable chapter navigation and a chapter/page scrubber.
3. Add bookmarks, selection, highlights and notes backed by a local database.
4. Add dictionary lookup and selectable text actions.
5. Add metadata editing, covers, tags and collections.
6. Add reading statistics and per-book history.
7. Add import/export of library metadata and annotations.
8. Add optional private device-to-device sync.
9. Add E-Ink refresh strategies and hardware-specific tuning.
10. Add the experimental feature layer for genuinely new reading interactions.

## Product rule
The core reading path must remain fast, private, and useful with zero network access. New features should be modular so the reader never becomes dependent on cloud services or bloated UI.
