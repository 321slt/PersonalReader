# Personal Reader — Android prototype

A private, offline-first EPUB reader built for personal use and E-Ink devices.

## Included in this first build
- Native Android app shell
- First-run setup wizard with E-Ink mode
- Local EPUB import and on-device storage
- EPUB container/OPF/spine parsing
- Reflowable reader using WebView with horizontal paged layout
- Font size control
- Light/dark reading themes
- E-Ink-friendly no-animation reader mode
- Local reading progress persistence
- Library view with title/author/progress
- Architecture intended for bookmarks, highlights, notes, dictionary, sync, reading stats and experimental features

## Build
Open this folder in Android Studio Quail 4 (2026.1.4) or newer, let Gradle sync, then run the `app` configuration on an Android phone or E-Ink Android device.

The project uses the current Android tooling versions documented on Android Developers in September 2026: AGP 9.4.0, Kotlin 2.4.20 and Compose BOM 2026.08.00.

## Important prototype limitation
This is a real starting application, not yet a feature-complete KOReader replacement. The next engineering pass should replace the prototype EPUB rendering layer with a dedicated production EPUB engine, then add robust annotations/bookmarks, dictionaries, metadata editing, chapter navigation, import/export, sync and E-Ink refresh tuning.


## Verification
Run `scripts/verify_project.sh` for source/package sanity checks. Device/emulator build requires an Android SDK plus Gradle 9.6.0; the project is pinned accordingly.
