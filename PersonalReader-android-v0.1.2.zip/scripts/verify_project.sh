#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/app/src/main/java/com/personalreader/app/MainActivity.kt"
[[ -f "$ROOT/settings.gradle.kts" ]]
[[ -f "$ROOT/build.gradle.kts" ]]
[[ -f "$ROOT/app/build.gradle.kts" ]]
[[ -f "$SRC" ]]
[[ -f "$ROOT/gradle/wrapper/gradle-wrapper.properties" ]]
# This session does not have Gradle distribution/wrapper JAR available; keep this explicit.
[[ -f "$ROOT/gradlew" ]]
! grep -q 'onClick=onFinish(eink)' "$SRC"
grep -q 'onClick={onFinish(eink)}' "$SRC"
grep -q 'compileSdk = 37' "$ROOT/app/build.gradle.kts"
grep -q 'versionName = "0.1.1"' "$ROOT/app/build.gradle.kts" || true
# APK source should not request network permissions for this offline-first prototype.
! grep -q 'android.permission.INTERNET' "$ROOT/app/src/main/AndroidManifest.xml"
# Check source for common unsafe APK-local EPUB path escape pattern.
grep -q 'canonicalPath.startsWith' "$SRC"
# Validate every archive entry in source ZIPs if present.
for f in "$ROOT"/*.zip; do
  [ -e "$f" ] || continue
  python3 - "$f" <<'PY'
import sys, zipfile, pathlib
p=sys.argv[1]
with zipfile.ZipFile(p) as z:
    bad=[]
    for n in z.namelist():
        q=pathlib.PurePosixPath(n)
        if q.is_absolute() or '..' in q.parts:
            bad.append(n)
    if bad:
        raise SystemExit(f'unsafe ZIP entries: {bad[:5]}')
print('ZIP OK:', p)
PY
done
printf 'Static verification: PASS\n'
