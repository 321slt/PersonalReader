# Personal Reader — Android 4.11 shell

This project packages the unchanged Personal Reader 4.11 web app inside a native Android WebView shell.

## Why this architecture

The reader, pagination, themes, annotations, IndexedDB library and PWA logic remain the same codebase. Android-specific responsibilities are kept in the shell: lifecycle, local asset serving, Android document picking, renderer-crash recovery and external URI handling.

This avoids rewriting the working reader engine in a second UI framework and prevents Android and web versions from drifting apart.

## Toolchain

- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- compileSdk / targetSdk: 37
- minSdk: 26
- AndroidX WebKit: 1.17.0
- JDK: 17

AGP 9.4.0 supports API 37 and uses Gradle 9.6.0. AndroidX WebKit 1.17.0 is the current stable WebKit release used for `WebViewAssetLoader`.

## Build

Open this directory in Android Studio Quail 4 (or a newer compatible Android Studio release), let Gradle sync, then build the debug APK from the Build menu.

The GitHub Actions workflow builds the debug APK automatically. It also works if the Android project is nested one folder below the repository root.

The generated debug APK will be under:

`app/build/outputs/apk/debug/app-debug.apk`

## Testing note

The JavaScript app is intentionally copied from Personal Reader v4.11. Changes to reader pagination or modal positioning should not be made in this wrapper. Android-specific work should stay isolated in `MainActivity.java` and future native bridge modules.
