# Personal Reader 4.12.4 logo update

- Adaptive Android launcher icon with monochrome themed-icon layer for Android 13+ / Samsung One UI themed icons.
- Human-made flat vector mark: open-book + subtle P geometry, no text and no glossy effects.
- Native launch animation now uses the launcher mark instead of a PR text badge.
- Web/PWA icon updated and cache-busted.
