# Android smoke-test checklist

After installing the debug APK on a phone or the Lenovo Smart Paper Android environment, test these before changing the reader engine:

1. Fresh launch shows Personal Reader setup and completes normally.
2. Library renders and survives app restart.
3. Import one EPUB from Files.
4. Import multiple EPUBs in one picker operation.
5. Open a book and verify first page, next/previous page and page count.
6. Verify page turning does not create horizontal free scrolling.
7. Verify Settings, Notes and Annotations are centered in the current viewport in every theme.
8. Test continuous-scroll mode and return to paged mode.
9. Test custom wallpaper/theme and verify the reader background is correct.
10. Test text selection/highlight/note creation.
11. Test search and exact-match navigation.
12. Test TTS start/pause/stop and chapter changes.
13. Background/foreground the app and verify reading progress persists.
14. Rotate the phone and verify the reader does not lose the open book or progress.
15. Press Android Back from the reader and from an opened external web page.
16. Put the app under memory pressure and reopen it; verify the library remains intact.
17. On E-Ink hardware, verify pen/finger annotation behavior separately; this cannot be simulated reliably on a normal browser.
