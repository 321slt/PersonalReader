package com.personalreader.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 42011;
    private static final int VERSION_CODE = 4124;
    private static final String START_PAGE = "www/index.html";

    private FrameLayout root;
    private WebView webView;
    private FrameLayout launchOverlay;
    private ValueCallback<Uri[]> pendingFileCallback;
    private long launchStartedAt;
    private boolean launchDismissed;
    private TextToSpeech textToSpeech;
    private boolean ttsReady;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindowForModernAndroid();
        requestBestRefreshRate();
        initTextToSpeech();
        createRootAndWebView();
        showLaunchAnimation();
    }

    private void configureWindowForModernAndroid() {
        Window window = getWindow();
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (Build.VERSION.SDK_INT >= 30) {
            window.setNavigationBarDividerColor(Color.TRANSPARENT);
            window.getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= 28) {
            window.setNavigationBarDividerColor(Color.TRANSPARENT);
            window.getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    private void requestBestRefreshRate() {
        if (Build.VERSION.SDK_INT < 30) {
            return;
        }
        Display display = getDisplay();
        if (display == null) {
            return;
        }
        Display.Mode current = display.getMode();
        Display.Mode best = current;
        for (Display.Mode mode : display.getSupportedModes()) {
            if (mode.getPhysicalWidth() != current.getPhysicalWidth()
                    || mode.getPhysicalHeight() != current.getPhysicalHeight()) {
                continue;
            }
            if (mode.getRefreshRate() > best.getRefreshRate()) {
                best = mode;
            }
        }
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.preferredRefreshRate = best.getRefreshRate();
        if (Build.VERSION.SDK_INT >= 31) {
            params.preferredDisplayModeId = best.getModeId();
        }
        getWindow().setAttributes(params);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void createRootAndWebView() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(11, 13, 16));
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        if (Build.VERSION.SDK_INT >= 26) {
            webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true);
        }

        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(webView, webParams);

        webView.setOnApplyWindowInsetsListener((view, insets) -> {
            applySafeInsets(insets);
            return insets;
        });

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= 26) {
            settings.setOffscreenPreRaster(true);
        }

        if (Build.VERSION.SDK_INT >= 29) {
            settings.setForceDark(WebSettings.FORCE_DARK_OFF);
        }

        CookieManager.getInstance().setAcceptCookie(true);

        webView.addJavascriptInterface(new AndroidTTSBridge(), "AndroidTTS");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternalIfNeeded(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalIfNeeded(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                        "document.documentElement.dataset.androidApp='true';"
                                + "document.documentElement.dataset.androidVersion='" + VERSION_CODE + "';"
                                + "(function(){var s=document.getElementById('pr-native-compat');"
                                + "if(!s){s=document.createElement('style');s.id='pr-native-compat';"
                                + "s.textContent='html,body{-webkit-tap-highlight-color:transparent;overscroll-behavior-x:none;}';"
                                + "document.head.appendChild(s);}})();",
                        null);
                scheduleLaunchDismissal(520);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                scheduleLaunchDismissal(0);
            }

            @Override
            public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                if (view == webView) {
                    view.destroy();
                    webView = null;
                    recreate();
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (pendingFileCallback != null) {
                    pendingFileCallback.onReceiveValue(null);
                }
                pendingFileCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                        "application/epub+zip",
                        "application/pdf",
                        "text/plain",
                        "text/markdown",
                        "text/html",
                        "application/xhtml+xml",
                        "application/zip",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "image/*",
                        "application/octet-stream"
                });

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    pendingFileCallback.onReceiveValue(null);
                    pendingFileCallback = null;
                    return false;
                }
            }
        });

        webView.post(() -> webView.requestApplyInsets());
        webView.loadUrl("file:///android_asset/" + START_PAGE);
    }

    private boolean openExternalIfNeeded(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null || "file".equalsIgnoreCase(scheme)) {
            return false;
        }
        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            } catch (ActivityNotFoundException ignored) {
                return false;
            }
        }
        return true;
    }

    private void applySafeInsets(android.view.WindowInsets insets) {
        int top;
        int bottom;
        int left;
        int right;

        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Insets system = insets.getInsets(
                    android.view.WindowInsets.Type.statusBars()
                            | android.view.WindowInsets.Type.navigationBars()
                            | android.view.WindowInsets.Type.displayCutout());
            android.graphics.Insets ime = insets.getInsets(android.view.WindowInsets.Type.ime());
            top = system.top;
            bottom = Math.max(system.bottom, ime.bottom);
            left = system.left;
            right = system.right;
        } else {
            top = insets.getSystemWindowInsetTop();
            bottom = insets.getSystemWindowInsetBottom();
            left = insets.getSystemWindowInsetLeft();
            right = insets.getSystemWindowInsetRight();
        }

        if (webView != null) {
            ViewGroup.LayoutParams raw = webView.getLayoutParams();
            FrameLayout.LayoutParams params = raw instanceof FrameLayout.LayoutParams
                    ? (FrameLayout.LayoutParams) raw
                    : new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT);
            if (params.leftMargin != left || params.topMargin != top
                    || params.rightMargin != right || params.bottomMargin != bottom) {
                params.leftMargin = left;
                params.topMargin = top;
                params.rightMargin = right;
                params.bottomMargin = bottom;
                webView.setLayoutParams(params);
            }
        }
    }

    private void showLaunchAnimation() {
        launchStartedAt = SystemClock.elapsedRealtime();

        launchOverlay = new FrameLayout(this);
        launchOverlay.setBackgroundColor(Color.rgb(11, 13, 16));
        launchOverlay.setClickable(true);
        launchOverlay.setFocusable(true);
        if (Build.VERSION.SDK_INT >= 21) {
            launchOverlay.setElevation(1000f);
        }

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.personalreader.app.R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setContentDescription("Personal Reader");
        logo.setElevation(dp(6));

        TextView title = new TextView(this);
        title.setText("Personal Reader");
        title.setTextColor(Color.WHITE);
        title.setTextSize(21f);
        title.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
        title.setGravity(Gravity.CENTER);

        TextView subtitle = new TextView(this);
        subtitle.setText("A calmer way to read.");
        subtitle.setTextColor(Color.rgb(166, 168, 176));
        subtitle.setTextSize(12f);
        subtitle.setGravity(Gravity.CENTER);

        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(88), dp(88));
        logoParams.bottomMargin = dp(24);
        content.addView(logo, logoParams);

        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleParams.bottomMargin = dp(8);
        content.addView(title, titleParams);
        content.addView(subtitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        contentParams.gravity = Gravity.CENTER;
        launchOverlay.addView(content, contentParams);
        root.addView(launchOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        logo.setScaleX(0.88f);
        logo.setScaleY(0.88f);
        logo.setAlpha(0f);
        title.setAlpha(0f);
        subtitle.setAlpha(0f);

        DecelerateInterpolator interpolator = new DecelerateInterpolator(1.7f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(520).setInterpolator(interpolator).start();
        title.animate().alpha(1f).setStartDelay(150).setDuration(420)
                .setInterpolator(interpolator).start();
        subtitle.animate().alpha(1f).setStartDelay(260).setDuration(360)
                .setInterpolator(interpolator).start();

        launchOverlay.postDelayed(() -> scheduleLaunchDismissal(0), 4000);
    }

    private void scheduleLaunchDismissal(long additionalDelay) {
        if (launchDismissed || launchOverlay == null) {
            return;
        }
        long elapsed = SystemClock.elapsedRealtime() - launchStartedAt;
        long minVisible = 650;
        long wait = Math.max(additionalDelay, minVisible - elapsed);
        launchOverlay.postDelayed(this::dismissLaunchAnimation, Math.max(0, wait));
    }

    private void dismissLaunchAnimation() {
        if (launchDismissed || launchOverlay == null) {
            return;
        }
        launchDismissed = true;
        launchOverlay.animate()
                .alpha(0f)
                .scaleX(1.015f)
                .scaleY(1.015f)
                .setDuration(360)
                .setInterpolator(new DecelerateInterpolator(1.5f))
                .withEndAction(() -> {
                    if (launchOverlay != null && root != null) {
                        root.removeView(launchOverlay);
                        launchOverlay = null;
                    }
                })
                .start();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void initTextToSpeech() {
        textToSpeech = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (textToSpeech != null) {
                textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) {}
                    @Override public void onDone(String utteranceId) {
                        if (webView != null) webView.post(() -> webView.evaluateJavascript(
                                "window.__prNativeTtsDone && window.__prNativeTtsDone('" + escapeJs(utteranceId) + "');", null));
                    }
                    @Override public void onError(String utteranceId) {
                        if (webView != null) webView.post(() -> webView.evaluateJavascript(
                                "window.__prNativeTtsDone && window.__prNativeTtsDone('" + escapeJs(utteranceId) + "');", null));
                    }
                });
            }
        });
    }

    private String escapeJs(String value) {
        return value == null ? "" : value.replace("\\", "\\\\").replace("'", "\\'");
    }

    private final class AndroidTTSBridge {
        @JavascriptInterface public boolean isReady() { return ttsReady && textToSpeech != null; }
        @JavascriptInterface public void speak(String text, float rate, float pitch, String language, String utteranceId) {
            if (!ttsReady || textToSpeech == null || text == null || text.isEmpty()) return;
            try {
                Locale locale = "tr".equalsIgnoreCase(language) ? Locale.forLanguageTag("tr-TR") : Locale.US;
                int avail = textToSpeech.setLanguage(locale);
                if (avail == TextToSpeech.LANG_MISSING_DATA || avail == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech.setLanguage(Locale.getDefault());
                }
                textToSpeech.setSpeechRate(Math.max(.55f, Math.min(1.4f, rate)));
                textToSpeech.setPitch(Math.max(.5f, Math.min(2f, pitch)));
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), utteranceId);
            } catch (Throwable ignored) {}
        }
        @JavascriptInterface public void stop() {
            if (textToSpeech != null) { try { textToSpeech.stop(); } catch (Throwable ignored) {} }
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        requestBestRefreshRate();
        if (webView != null) {
            webView.post(() -> webView.requestApplyInsets());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || pendingFileCallback == null) {
            return;
        }

        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) {
                    results[i] = data.getClipData().getItemAt(i).getUri();
                    persistReadPermission(results[i]);
                }
            } else if (data.getData() != null) {
                results = new Uri[] { data.getData() };
                persistReadPermission(data.getData());
            }
        }

        pendingFileCallback.onReceiveValue(results);
        pendingFileCallback = null;
    }

    private void persistReadPermission(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) {
        }
    }

    @Override
    public void onBackPressed() {
        if (launchOverlay != null && !launchDismissed) {
            dismissLaunchAnimation();
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        if (textToSpeech != null) { try { textToSpeech.stop(); textToSpeech.shutdown(); } catch (Throwable ignored) {} textToSpeech = null; ttsReady = false; }
        super.onDestroy();
    }
}
