import { getStore } from '@netlify/blobs';

const STORE = 'personalreader-sync-v1';
const json = (data, status=200) => new Response(JSON.stringify(data), {
  status,
  headers: {'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization, X-Sync-Id, X-Device-Id','Access-Control-Allow-Methods':'GET, PUT, OPTIONS'}
});

function auth(req){
  const id=req.headers.get('x-sync-id') || '';
  const token=(req.headers.get('authorization')||'').replace(/^Bearer\s+/i,'');
  return {id,token};
}
function key(id){return `sync/${id}`;}

export default async (req) => {
  if(req.method==='OPTIONS') return json({ok:true});
  const {id,token}=auth(req);
  if(!id || !token || id.length<8 || token.length<16) return json({error:'Invalid sync credentials.'},401);
  const store=getStore({name:STORE,consistency:'strong'});
  const existing=await store.get(key(id),{type:'json'});
  if(req.method==='GET'){
    if(!existing) return json({version:2,books:[],folders:[]});
    if(existing.token!==token) return json({error:'Invalid sync token.'},403);
    return json({version:2,books:existing.books||[],folders:existing.folders||[],updated:existing.updated||0});
  }
  if(req.method==='PUT'){
    if(existing && existing.token!==token) return json({error:'Invalid sync token.'},403);
    let body;
    try{body=await req.json();}catch{return json({error:'Invalid JSON.'},400);}
    if(!Array.isArray(body.books)) return json({error:'Invalid sync payload.'},400);
    const record={version:2,token,updated:Date.now(),deviceId:body.deviceId||'unknown',books:body.books,folders:Array.isArray(body.folders)?body.folders:[]};
    await store.setJSON(key(id),record);
    return json({ok:true,updated:record.updated});
  }
  return json({error:'Method not allowed.'},405);
};
