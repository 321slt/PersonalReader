import fs from 'node:fs';
import assert from 'node:assert/strict';
const css=fs.readFileSync(new URL('../styles.css', import.meta.url),'utf8');
assert.doesNotMatch(css,/html\[data-theme="custom"\] body > \*\{position:relative;/,'Broad custom body-child positioning must not capture overlays');
assert.match(css,/\.overlay\{[\s\S]*?position:fixed!important;[\s\S]*?padding:0!important;[\s\S]*?place-items:center!important;/,'Overlay portal must be viewport-fixed and centered');
assert.match(css,/\.modal\{[\s\S]*?margin:0!important;[\s\S]*?width:min\(640px,calc\(100vw - 36px\)\)!important;/,'Modal must be centered by the viewport grid with symmetric width bounds');
console.log('overlay-position static checks: PASS');
