(() => {
  'use strict';

  const DB_NAME = 'PersonalReaderDB';
  const STORE = 'books';
  const FOLDER_STORE = 'folders';
  const SETTINGS_KEY = 'PersonalReaderSettings';
  const DEFAULTS = { theme: 'obsidian', customWallpaper: '', customTone: 'dark', customBlur: 22, customMica: 38, customOpacity: 52, customPaletteSource: '', eink: false, font: 18, line: 1.65, setup: false, view: 'grid', sort: 'recent', filter: 'all', readerMode: 'scroll', pageTurn: 'curl', language: 'English', aiEndpoint: '', aiModel: 'gpt-4.1-mini', aiKey: '', syncUrl: '', syncId: '', syncToken: '', autoSync: true, deviceMode: 'auto', penAuto: true, annotationTool: 'pen', annotationColor: 'accent', ttsRate: 0.88, ttsPitch: 1, ttsVoice: '', annotationInput: 'pen' };
  let db = null, books = [], current = null, currentChapter = 0, currentStart = 0, currentPage = 0, pendingSearch = '';
  const DEVICE_KEY = 'PersonalReaderDeviceId';
  const SYNC_KEY = 'PersonalReaderSync';
  let syncBusy = false, folders = [], currentFolderId = null, pendingAnnotationNav = null, readingStartedAt = 0, readingTickTimer = 0, readingLastCheckpointAt = 0, readingPaused = false, pageReflowTimer=0, pageTurnToken=0, ttsPanelEl=null;

  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
  const clamp = (n,a,b) => Math.max(a, Math.min(b,n));
  const delay = ms => new Promise(r => setTimeout(r, ms));
  const uid = () => { try { if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID(); } catch {} return `${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`; };
  async function digestHex(input){ try { if(globalThis.crypto?.subtle){ const data=typeof input==='string'?new TextEncoder().encode(input):input; const digest=await globalThis.crypto.subtle.digest('SHA-256',data); return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join(''); } } catch {} let h1=2166136261,h2=16777619; const bytes=typeof input==='string'?new TextEncoder().encode(input):new Uint8Array(input); for(const b of bytes){h1^=b;h1=Math.imul(h1,16777619);h2^=b;h2=Math.imul(h2,2166136261);} return (h1>>>0).toString(16).padStart(8,'0')+(h2>>>0).toString(16).padStart(8,'0'); }
  async function fileArrayBuffer(file){ if(file?.arrayBuffer) return file.arrayBuffer(); return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(r.error||new Error('The selected file could not be read.'));r.readAsArrayBuffer(file);}); }
  const deviceId = localStorage.getItem(DEVICE_KEY) || (() => { const id=uid(); localStorage.setItem(DEVICE_KEY,id); return id; })();

  let settings = { ...DEFAULTS };
  let customPaletteEpoch=0;
  try { settings = { ...DEFAULTS, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') }; } catch {}
  if (settings.theme === 'dark') settings.theme = 'obsidian';
  if (settings.theme === 'light') settings.theme = 'paper';

  function effectiveDeviceClass(){
    if(settings.deviceMode==='phone') return 'phone';
    if(settings.deviceMode==='tablet') return 'tablet';
    return (settings.eink || window.innerWidth>=900 || Math.min(window.innerWidth,window.innerHeight)>=700) ? 'tablet' : 'phone';
  }
  function rgbToHex(r,g,b){return '#'+[r,g,b].map(v=>Math.round(clamp(v,0,255)).toString(16).padStart(2,'0')).join('');}
  function rgbToHsl(r,g,b){r/=255;g/=255;b/=255;const max=Math.max(r,g,b),min=Math.min(r,g,b);let h=0,s=0,l=(max+min)/2,d=max-min;if(d){s=d/(1-Math.abs(2*l-1));switch(max){case r:h=((g-b)/d)%6;break;case g:h=(b-r)/d+2;break;default:h=(r-g)/d+4;}h*=60;if(h<0)h+=360;}return [h,s,l];}
  function hslToRgb(h,s,l){h/=360;const f=(p,q,t)=>{if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return p+(q-p)*6*t;if(t<1/2)return q;if(t<2/3)return p+(q-p)*(2/3-t)*6;return p;};if(!s)return [l*255,l*255,l*255];const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q;return [f(p,q,h+1/3)*255,f(p,q,h)*255,f(p,q,h-1/3)*255];}
  function luminanceHex(hex){const m=/^#?([0-9a-f]{6})$/i.exec(hex||'');if(!m)return .5;const n=parseInt(m[1],16),v=x=>{x/=255;return x<=.03928?x/12.92:Math.pow((x+.055)/1.055,2.4)};return .2126*v(n>>16&255)+.7152*v(n>>8&255)+.0722*v(n&255);}
  async function deriveWallpaperPalette(dataUrl, tone=settings.customTone||'dark'){return new Promise(resolve=>{try{const img=new Image();img.onload=()=>{try{const c=document.createElement('canvas');c.width=40;c.height=40;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,0,0,40,40);const px=ctx.getImageData(0,0,40,40).data;let rsum=0,gsum=0,bsum=0,n=0,best={score:0,r:0,g:0,b:0};for(let i=0;i<px.length;i+=4){if(px[i+3]<100)continue;const r=px[i],g=px[i+1],b=px[i+2];rsum+=r;gsum+=g;bsum+=b;n++;const [h,ss,ll]=rgbToHsl(r,g,b);const score=ss*(.65+.35*(1-Math.abs(ll-.5)*1.6));if(score>best.score)best={score,r,g,b};}if(!n)return resolve(null);const avg=[rsum/n,gsum/n,bsum/n],avgHex=rgbToHex(...avg);let [h,ss,ll]=rgbToHsl(best.r,best.g,best.b);if(ss<.20){[h,ss,ll]=rgbToHsl(...avg);ss=.60;}ss=clamp(ss,.42,.82);const dark=tone!=='light';const text=dark?'#f6f8fb':'#15181d',muted=dark?'#c6ced8':'#4c5663';const targetBg=dark?[13,17,23]:[246,243,237];const targetSurface=dark?[24,29,38]:[255,252,246];const targetSurface2=dark?[34,41,52]:[239,235,226];const targetLine=dark?[72,82,96]:[177,171,160];const mix=(a,b,t)=>a.map((v,i)=>v*(1-t)+b[i]*t);const bg=rgbToHex(...mix(avg,targetBg,.72));const surface=rgbToHex(...mix(avg,targetSurface,.82));const surface2=rgbToHex(...mix(avg,targetSurface2,.74));const line=rgbToHex(...mix(avg,targetLine,.55));ll=dark?clamp(.54-(ll-.5)*.16,.40,.62):clamp(.48+(ll-.5)*.10,.34,.62);let accentL=ll;let accent=rgbToHex(...hslToRgb(h,ss,accentL));const onAccent=dark?'#071018':'#ffffff';const onAccentAlt=dark?'#ffffff':'#071018';const cr=(a,b)=>{const la=luminanceHex(a),lb=luminanceHex(b);return (Math.max(la,lb)+.05)/(Math.min(la,lb)+.05)};let guard=0;while(cr(accent,onAccent)<4.6&&guard++<18){accentL=dark?Math.min(.82,accentL+.025):Math.max(.24,accentL-.025);accent=rgbToHex(...hslToRgb(h,ss,accentL));}const safeOnAccent=cr(accent,onAccent)>=4.6?onAccent:onAccentAlt;const accent2=rgbToHex(...hslToRgb((h+22)%360,Math.min(.88,ss+.04),dark?clamp(accentL+.10,.46,.78):clamp(accentL-.08,.24,.58)));const readerPaper=dark?rgbToHex(...mix(avg,[30,35,44],.86)):rgbToHex(...mix(avg,[255,253,247],.90));resolve({tone:dark?'dark':'light',avg:avgHex,bg,accent,accent2,onAccent:safeOnAccent,text,muted,surface,surface2,line,readerPaper,readerInk:text});}catch{resolve(null);}};img.onerror=()=>resolve(null);img.src=dataUrl;}catch{resolve(null);}});}
  function syncCustomWallpaperLayer(){
    // v4.8: keep the wallpaper on the actual body, as in the first working
    // Custom-theme implementation. This gives backdrop-filter a real ancestor
    // backdrop and avoids sibling-layer/compositing inconsistencies.
    const old=document.getElementById('customWallpaperLayer');
    if(old) old.remove();
    const root=document.documentElement, body=document.body;
    if(!body) return;
    const active=settings.theme==='custom' && !!settings.customWallpaper;
    body.style.setProperty('background-color',settings.customPalette?.bg||settings.customPalette?.avg||'#0c1119','important');
    body.style.setProperty('background-image',active
      ? `linear-gradient(180deg,color-mix(in srgb,${settings.customPalette?.bg||'#0c1119'} var(--custom-opacity-pct,52%),transparent),color-mix(in srgb,${settings.customPalette?.bg||'#0c1119'} calc(var(--custom-opacity-pct,52%) * .82),transparent)),var(--custom-wallpaper)`
      : 'none','important');
    body.style.setProperty('background-size',active?'cover':'auto','important');
    body.style.setProperty('background-position',active?'center':'0 0','important');
    body.style.setProperty('background-repeat',active?'no-repeat':'repeat','important');
    body.style.setProperty('background-attachment',active?'fixed':'scroll','important');
    root.style.setProperty('--custom-wallpaper',settings.customWallpaper?`url(${JSON.stringify(settings.customWallpaper)})`:'none');
  }

  function clearCustomPaletteAliases(){
    const keys=['accent','accent2','on-accent','text','muted','surface','surface2','line','bg','reader-paper','reader-ink','danger'];
    keys.forEach(k=>document.documentElement.style.removeProperty(`--${k}`));
  }

  function applySettings(){
    document.documentElement.dataset.theme=settings.theme||'obsidian';document.documentElement.dataset.customTone=settings.customTone||'dark';clearCustomPaletteAliases();
    const cp=settings.customPalette||{},cv={accent:cp.accent||'#78d9ff',accent2:cp.accent2||'#b5eaff',onAccent:cp.onAccent||(settings.customTone==='light'?'#ffffff':'#071018'),text:cp.text||'#f4f7fb',muted:cp.muted||'#c1cad6',surface:cp.surface||'#1a2230',surface2:cp.surface2||'#223043',line:cp.line||'#405064',bg:cp.avg||'#0c1119',readerPaper:cp.readerPaper||cp.surface||'#1a2230',readerInk:cp.readerInk||cp.text||'#f4f7fb'};for(const [k,v] of Object.entries(cv))document.documentElement.style.setProperty('--custom-'+k,v);if(settings.theme==='custom'){for(const [k,v] of [['accent','--custom-accent'],['accent2','--custom-accent2'],['on-accent','--custom-on-accent'],['text','--custom-text'],['muted','--custom-muted'],['surface','--custom-surface'],['surface2','--custom-surface2'],['line','--custom-line'],['bg','--custom-bg'],['reader-paper','--custom-readerPaper'],['reader-ink','--custom-readerInk']])document.documentElement.style.setProperty('--'+k,'var('+v+')');}else{['accent','accent2','text','muted','surface','surface2','line','bg','reader-paper','reader-ink'].forEach(k=>document.documentElement.style.removeProperty('--'+k));}
    document.documentElement.classList.toggle('eink',!!settings.eink);document.documentElement.classList.toggle('annotation-draw-both',settings.annotationInput==='both');
    document.documentElement.style.setProperty('--reader-font',`${settings.font}px`);
    document.documentElement.style.setProperty('--reader-line',settings.line);
    document.documentElement.dataset.readerMode=settings.readerMode||'scroll';
    document.documentElement.dataset.deviceMode=settings.deviceMode||'auto';
    document.documentElement.dataset.deviceClass=effectiveDeviceClass();
    document.documentElement.dataset.annotationTool=settings.annotationTool||'pen';
    document.documentElement.style.setProperty('--custom-blur',`${clamp(+settings.customBlur||18,0,40)}px`);
    document.documentElement.style.setProperty('--custom-mica',`${clamp(+settings.customMica||34,0,100)}%`);
    const customOpacity=clamp(+settings.customOpacity||52,15,100);document.documentElement.style.setProperty('--custom-opacity',`${customOpacity/100}`);document.documentElement.style.setProperty('--custom-opacity-pct',`${customOpacity}%`);
    document.documentElement.style.setProperty('--custom-wallpaper',settings.customWallpaper?`url(${JSON.stringify(settings.customWallpaper)})`:'none');
    syncCustomWallpaperLayer();
    {const requestWallpaper=settings.customWallpaper||'',requestTone=settings.customTone||'dark',requestEpoch=++customPaletteEpoch;if(settings.theme==='custom'&&requestWallpaper&&!document.documentElement.dataset.palettePending){document.documentElement.dataset.palettePending='1';digestHex(requestWallpaper).then(async source=>{if(requestEpoch!==customPaletteEpoch||settings.theme!=='custom'||settings.customWallpaper!==requestWallpaper||settings.customTone!==requestTone){delete document.documentElement.dataset.palettePending;return;}if(source===settings.customPaletteSource&&settings.customPalette){delete document.documentElement.dataset.palettePending;return;}const p=await deriveWallpaperPalette(requestWallpaper,requestTone);if(requestEpoch!==customPaletteEpoch||settings.theme!=='custom'||settings.customWallpaper!==requestWallpaper||settings.customTone!==requestTone){delete document.documentElement.dataset.palettePending;return;}delete document.documentElement.dataset.palettePending;settings.customPalette=p||null;settings.customPaletteSource=source;applySettings();});}}
    const themeColors={obsidian:'#0b0d10',paper:'#f3f0e8',nord:'#2e3440',dracula:'#282a36',solarized:'#002b36',gruvbox:'#282828',catppuccin:'#1e1e2e',rosepine:'#191724',cyber:'#070a10',everforest:'#2d353b',kanagawa:'#1f1f28',tokyo:'#16161e',midnight:'#080b14',sepia:'#e9dcc8',custom:'#0c1119'};
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content',themeColors[settings.theme]||'#0b0d10');
    localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings));
  }
  function openDB() {
    return new Promise((resolve,reject) => {
      const req = indexedDB.open(DB_NAME, 4);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains(STORE)) d.createObjectStore(STORE, { keyPath:'id' });
        if (!d.objectStoreNames.contains(FOLDER_STORE)) d.createObjectStore(FOLDER_STORE, { keyPath:'id' });
      };
      req.onsuccess = () => { db=req.result; resolve(); };
      req.onerror = () => reject(req.error || new Error('Local storage could not be opened.'));
    });
  }
  function tx(mode, fn, storeName=STORE) {
    return new Promise((resolve,reject) => {
      const t=db.transaction(storeName,mode), s=t.objectStore(storeName); let result;
      try { result=fn(s); } catch(e) { reject(e); return; }
      t.oncomplete=()=>resolve(result); t.onerror=()=>reject(t.error);
    });
  }
  const put = b => tx('readwrite', s => s.put(b));
  const del = id => tx('readwrite', s => s.delete(id));
  const all = () => new Promise((resolve,reject) => { const t=db.transaction(STORE,'readonly'), r=t.objectStore(STORE).getAll(); r.onsuccess=()=>resolve(r.result||[]); r.onerror=()=>reject(r.error); });
  const putFolder = f => tx('readwrite', s => s.put(f), FOLDER_STORE);
  const delFolder = id => tx('readwrite', s => s.delete(id), FOLDER_STORE);
  const allFolders = () => new Promise((resolve,reject) => { const t=db.transaction(FOLDER_STORE,'readonly'), r=t.objectStore(FOLDER_STORE).getAll(); r.onsuccess=()=>resolve(r.result||[]); r.onerror=()=>reject(r.error); });

  class ZipReader {
    constructor(buffer){ this.buffer=buffer; this.view=new DataView(buffer); this.entries=new Map(); }
    parse(){
      const v=this.view, len=v.byteLength; let eocd=-1;
      for(let i=len-22;i>=Math.max(0,len-65557);i--) if(v.getUint32(i,true)===0x06054b50){eocd=i;break;}
      if(eocd<0) throw new Error('The selected file is not a valid EPUB/ZIP archive.');
      let count=v.getUint16(eocd+10,true), cdSize=v.getUint32(eocd+12,true), cdOffset=v.getUint32(eocd+16,true);
      // ZIP64: locate the ZIP64 end-of-central-directory record when classic fields overflow.
      if(count===0xffff || cdSize===0xffffffff || cdOffset===0xffffffff){
        const loc=Math.max(0,eocd-1024);
        let z64=-1; for(let i=eocd-20;i>=loc;i--) if(v.getUint32(i,true)===0x06064b50){z64=i;break;}
        if(z64>=0){
          count=Number(v.getBigUint64(z64+32,true)); cdSize=Number(v.getBigUint64(z64+40,true)); cdOffset=Number(v.getBigUint64(z64+48,true));
        } else throw new Error('This ZIP archive uses ZIP64 but its directory could not be read.');
      }
      let p=cdOffset;
      for(let n=0;n<count;n++){
        if(v.getUint32(p,true)!==0x02014b50) throw new Error('The EPUB archive directory is invalid.');
        const flags=v.getUint16(p+8,true), method=v.getUint16(p+10,true), comp32=v.getUint32(p+20,true), uncomp32=v.getUint32(p+24,true);
        const nl=v.getUint16(p+28,true), xl=v.getUint16(p+30,true), cl=v.getUint16(p+32,true), local32=v.getUint32(p+42,true);
        const bytes=new Uint8Array(this.buffer,p+46,nl);
        const name=new TextDecoder('utf-8',{fatal:false}).decode(bytes);
        let comp=comp32, uncomp=uncomp32, local=local32;
        if(comp32===0xffffffff || uncomp32===0xffffffff || local32===0xffffffff){
          let q=p+46+nl, end=q+xl, found=false;
          while(q+4<=end){ const id=v.getUint16(q,true), sz=v.getUint16(q+2,true); q+=4; if(id===0x0001){let r=q;if(uncomp32===0xffffffff){uncomp=Number(v.getBigUint64(r,true));r+=8;}if(comp32===0xffffffff){comp=Number(v.getBigUint64(r,true));r+=8;}if(local32===0xffffffff)local=Number(v.getBigUint64(r,true));found=true;break;}q+=sz; }
          if(!found) throw new Error(`ZIP64 metadata is missing for ${name}.`);
        }
        this.entries.set(name,{name,method,comp,uncomp,local,flags}); p+=46+nl+xl+cl;
      }
      if(!this.entries.size) throw new Error('The EPUB archive contains no files.');
      return this;
    }
    find(name){ if(this.entries.has(name)) return name; let key; try{key=decodeURIComponent(String(name||''));}catch{key=String(name||'');} key=key.replace(/^\.\//,''); for(const k of this.entries.keys()){if(k===key||k.replace(/^\.\//,'')===key) return k;} return null; }
    async bytes(name){
      const key=this.find(name); const e=key?this.entries.get(key):null; if(!e) return null;
      const v=this.view,p=e.local; if(v.getUint32(p,true)!==0x04034b50) throw new Error(`Invalid EPUB entry: ${name}`);
      const nl=v.getUint16(p+26,true),xl=v.getUint16(p+28,true),start=p+30+nl+xl,compressed=new Uint8Array(this.buffer,start,e.comp);
      if(e.method===0) return compressed.slice();
      if(e.method!==8) throw new Error(`This EPUB uses an unsupported compression method (${e.method}).`);
      if(!('DecompressionStream' in window)) throw new Error('Your browser cannot decompress EPUB files. Update Chrome or Samsung Internet.');
      const run=async format=>new Uint8Array(await new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream(format))).arrayBuffer());
      try{return await run('deflate-raw');}catch{try{return await run('deflate');}catch{throw new Error(`Could not decompress EPUB entry: ${name}`);}}
    }
    async text(name){ const b=await this.bytes(name); return b?new TextDecoder('utf-8',{fatal:false}).decode(b):null; }
  }

  const norm = (base, href) => {
    try {
      const clean=decodeURIComponent(String(href||'').split('#')[0].replace(/\\/g,'/'));
      const stack=base.split('/').filter(Boolean);
      for(const part of clean.split('/')) { if(!part||part==='.') continue; if(part==='..') stack.pop(); else stack.push(part); }
      return stack.join('/');
    } catch { return href; }
  };
  const dirname = p => { const i=p.lastIndexOf('/'); return i<0?'':p.slice(0,i+1); };
  const resourcePath = (base, href) => {
    const raw = String(href ?? '').trim();
    if (!raw || /^(?:https?:|data:|blob:|javascript:|mailto:|tel:|#)/i.test(raw)) return null;
    try { return norm(base, raw); } catch { return null; }
  };
  function sanitizeCss(raw, base, resources){
    let css=String(raw ?? '');
    css=css.replace(/\s*[@]import\b[^;]+;?/gi,'');
    css=css.replace(/expression\s*\([^)]*\)/gi,'');
    css=css.replace(/url\(\s*(["']?)([^)"']+)\1\s*\)/gi,(all,q,value)=>{
      const v=String(value).trim();
      if (/^(?:data:|blob:|https?:|#)/i.test(v)) return /^data:|^blob:/i.test(v)?all:'none';
      const target=resourcePath(base,v);
      return target && resources?.has(target) ? `url(${q}${resources.get(target)}${q})` : 'none';
    });
    css=css.replace(/(@font-face\s*\{[\s\S]*?\})/gi,m=>m.replace(/src\s*:[^;]+;/gi,(decl)=>decl));
    return css;
  }
  const strip = s => { const d=document.createElement('div'); d.innerHTML=s||''; return (d.textContent||'').replace(/\s+/g,' ').trim(); };
  const attr = (tag,name) => { const m=tag.match(new RegExp(`${name}\\s*=\\s*["']([^"']*)["']`,'i')); return m?m[1]:''; };
  const mime = p => ({jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',gif:'image/gif',webp:'image/webp',svg:'image/svg+xml',avif:'image/avif',css:'text/css',woff:'font/woff',woff2:'font/woff2',otf:'font/otf',ttf:'font/ttf'}[p.split('.').pop().toLowerCase()]||'application/octet-stream');
  const dataUrl = async(zip,path) => { const b=await zip.bytes(path); if(!b)return null; return await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>rej(r.error);r.readAsDataURL(new Blob([b],{type:mime(path)}));}); };

  function sanitizeHtml(raw, base, resources) {
    let html=String(raw||'').replace(/<script\b[\s\S]*?<\/script>/gi,'').replace(/<iframe\b[\s\S]*?<\/iframe>/gi,'').replace(/<object\b[\s\S]*?<\/object>/gi,'').replace(/<embed\b[^>]*>/gi,'');
    html=html.replace(/\son[a-z]+\s*=\s*(["'])[\s\S]*?\1/gi,'');
    html=html.replace(/\b(src|href)\s*=\s*(["'])([^"']+)\2/gi,(all,key,q,value)=>{
      if(/^(?:https?:|data:|#|mailto:|javascript:|tel:)/i.test(value)) return key==='href'&&value.startsWith('#')?all:`${key}=${q}#${q}`;
      const target=resourcePath(base,value); return target&&resources.has(target)?`${key}=${q}${resources.get(target)}${q}`:key==='href'&&value.startsWith('#')?all:`${key}=${q}#${q}`;
    });
    html=html.replace(/url\(\s*(["']?)([^)"']+)\1\s*\)/gi,(all,q,value)=>{const target=norm(base,value);return resources.has(target)?`url(${q}${resources.get(target)}${q})`:all;});
    return html.replace(/<head[\s\S]*?<\/head>/i,'').replace(/<\/?(?:html|body)[^>]*>/gi,'').replace(/\sstyle\s*=\s*([\"'])[\s\S]*?\1/gi,'');
  }

  async function fingerprintBook(title,author,chapters){
    const raw=[title,author,...chapters.map(c=>`${c.title}\n${c.html}`)].join('\n\u0000');
    return 'epub-'+await digestHex(raw);
  }

  function folderPath(folderId){ const chain=[]; let cur=folders.find(f=>f.id===folderId); let guard=0; while(cur&&guard++<80){chain.unshift(cur.name);cur=folders.find(f=>f.id===cur.parentId);} return chain.join(' / '); }
  function folderChildren(parentId){ return folders.filter(f=>(f.parentId||null)===(parentId||null)).sort((a,b)=>a.name.localeCompare(b.name)); }
  async function createFolder(parentId){ const name=prompt('Folder name:','New folder'); if(!name?.trim()) return; const n=name.trim(); if(folderChildren(parentId).some(f=>f.name.toLocaleLowerCase()===n.toLocaleLowerCase())){showToast('A folder with that name already exists.',true);return;} const f={id:uid(),name:n,parentId:parentId||null,created:Date.now(),updated:Date.now()};await putFolder(f);folders=await allFolders();library();showToast(`Folder “${n}” created.`); }
  async function removeFolder(folderId){ const f=folders.find(x=>x.id===folderId);if(!f)return;const hasBooks=books.some(b=>b.folderId===folderId),hasChildren=folders.some(x=>x.parentId===folderId);if(hasBooks||hasChildren){showToast('Move the books and folders out before deleting this folder.',true);return;}if(confirm(`Delete folder “${f.name}”?`)){await delFolder(folderId);folders=await allFolders();currentFolderId=f.parentId||null;library();}}
  function moveBookUI(book){ if(!book)return; const choices=[{id:null,name:'Library root'},...folders.map(f=>({id:f.id,name:folderPath(f.id)}))]; const o=overlay(`<div class="modal-head"><div><div class="eyebrow">ORGANIZE</div><h2>Move book</h2></div><button class="close">×</button></div><label class="label">Destination<select class="field" id="moveFolder">${choices.map(x=>`<option value="${esc(x.id||'')}">${esc(x.name)}</option>`).join('')}</select></label><div class="modal-foot"><button class="text-btn" id="cancelMove">Cancel</button><button class="cta" id="doMove">Move <span>→</span></button></div>`);$('.close',o).onclick=()=>o.remove();$('#cancelMove',o).onclick=()=>o.remove();$('#moveFolder',o).value=book.folderId||'';$('#doMove',o).onclick=async()=>{book.folderId=$('#moveFolder',o).value||null;book.updated=Date.now();await put(book);books=await all();o.remove();renderLibrary($('#libraryFilter')?.value||'');showToast('Book moved.');}; }
  async function importGeneric(file, folderId){
    const name=file?.name||'',ext=(name.split('.').pop()||'').toLowerCase(); if(!file)return;
    if(ext==='epub') return importBook(file,folderId);
    const supported=['pdf','txt','md','markdown','html','htm','docx','cbz'];
    if(!supported.includes(ext)){showToast('Supported files: EPUB, PDF, TXT, Markdown, HTML, DOCX and CBZ.',true);return;}
    const btn=$('#import');if(btn){btn.disabled=true;btn.dataset.old=btn.innerHTML;btn.innerHTML='<span class="spinner"></span> Adding…';}
    try{
      const buf=await fileArrayBuffer(file), title=name.replace(/\.(pdf|txt|md|markdown|html?|docx|cbz)$/i,'')||'Untitled';let chapters=[];
      if(ext==='pdf') chapters=[{title:'PDF document',html:'',pdf:true}];
      else if(ext==='docx'){
        const zip=new ZipReader(buf).parse(),xml=await zip.text('word/document.xml');if(!xml)throw new Error('DOCX document.xml is missing.');
        const tmp=xml.replace(/<w:tab\s*\/?>(?=\s*)/gi,'\t').replace(/<w:br\s*\/?>(?=\s*)/gi,'<br>').replace(/<w:p[ >][\s\S]*?<\/w:p>/gi,m=>`<p>${m.replace(/<w:(?:t|delText)\b[^>]*>([\s\S]*?)<\/w:(?:t|delText)>/gi,'$1').replace(/<[^>]+>/g,'')}</p>`);chapters=[{title:'Document',html:tmp}];
      } else if(ext==='cbz'){
        const zip=new ZipReader(buf).parse(),imgs=[];for(const path of [...zip.entries.keys()].sort()){if(/\.(jpe?g|png|gif|webp|avif)$/i.test(path)){const u=await dataUrl(zip,path);if(u)imgs.push({path,u});}}
        if(!imgs.length)throw new Error('The CBZ archive contains no supported images.');chapters=imgs.map((x,i)=>({title:`Page ${i+1}`,html:`<div class="comic-page"><img src="${x.u}" alt="Page ${i+1}"></div>`}));
      } else {const raw=new TextDecoder().decode(buf);chapters=[{title:'Document',html:(ext==='html'||ext==='htm')?sanitizeHtml(raw,'',new Map()):`<pre class="plain-document">${esc(raw)}</pre>`}];}
      const id='file-'+await digestHex(buf),old=books.find(b=>b.id===id);
      const book={id,title,author:'',type:ext==='markdown'?'md':ext,chapters,progress:old?.progress||0,chapter:old?.chapter||0,scroll:old?.scroll||0,page:old?.page||0,added:old?.added||Date.now(),updated:Date.now(),cover:old?.cover||null,bookmarks:old?.bookmarks||[],highlights:old?.highlights||[],notes:old?.notes||[],pageAnnotations:old?.pageAnnotations||[],readingSeconds:old?.readingSeconds||0,minutes:old?.minutes||0,history:old?.history||[],readingUpdated:old?.readingUpdated||Date.now(),favorite:!!old?.favorite,deviceUpdated:{...(old?.deviceUpdated||{}),[deviceId]:Date.now()},folderId:folderId??old?.folderId??null,fileBlob:ext==='pdf'?new Blob([buf],{type:'application/pdf'}):null};
      await put(book);books=await all();library();showToast(old?`“${title}” refreshed.`:`“${title}” added to your library.`);
    }catch(e){console.error(e);showToast(`Could not add “${name}”: ${e.message||'Unknown error'}`,true);}finally{if(btn){btn.disabled=false;btn.innerHTML=btn.dataset.old||'Add files';}}
  }


  function xmlChildren(doc,name){ return [...doc.getElementsByTagName('*')].filter(el=>el.localName===name); }
  function xmlAttr(el,name){ return el?.getAttribute?.(name)||el?.getAttributeNS?.(null,name)||''; }
  function parseEpubContainer(xml){
    const doc=new DOMParser().parseFromString(xml,'application/xml');
    if(doc.querySelector('parsererror')) throw new Error('The EPUB container XML is malformed.');
    const root=xmlChildren(doc,'rootfile').find(x=>xmlAttr(x,'full-path'));
    return root?xmlAttr(root,'full-path'):'';
  }
  function parseEpubPackage(xml){
    const doc=new DOMParser().parseFromString(xml,'application/xml');
    if(doc.querySelector('parsererror')) throw new Error('The EPUB package XML is malformed.');
    const manifest=new Map();
    for(const item of xmlChildren(doc,'item')){
      const id=xmlAttr(item,'id'),href=xmlAttr(item,'href'),media=xmlAttr(item,'media-type'),properties=xmlAttr(item,'properties');
      if(id&&href)manifest.set(id,{path:href,media,properties});
    }
    const spineIds=xmlChildren(doc,'itemref').map(x=>xmlAttr(x,'idref')).filter(Boolean);
    const spine=spineIds.map(id=>manifest.get(id)).filter(x=>x&&(/^(?:application\/xhtml\+xml|text\/html)$/i.test(x.media)||/\.(xhtml?|html?)$/i.test(x.path)));
    const title=xmlChildren(doc,'title')[0]?.textContent?.trim()||'';
    const creator=xmlChildren(doc,'creator')[0]?.textContent?.trim()||'';
    const coverMeta=xmlChildren(doc,'meta').find(x=>xmlAttr(x,'name').toLowerCase()==='cover');
    const coverId=coverMeta?xmlAttr(coverMeta,'content'):'';
    return {manifest,spine,spineIds,title,creator,coverId};
  }
  async function importBook(file, folderId=null) {
    if(!file)return;
    const name=String(file.name||'').trim();
    if(!/\.epub$/i.test(name)){showToast('Please choose an EPUB file here.',true);return;}
    const btn=$('#import');if(btn){btn.disabled=true;btn.dataset.old=btn.innerHTML;btn.innerHTML='<span class="spinner"></span> Importing…';}
    try{
      const buffer=await fileArrayBuffer(file);
      if(!buffer||buffer.byteLength<22) throw new Error('The selected EPUB file is empty or incomplete.');
      const zip=new ZipReader(buffer).parse();
      const container=await zip.text('META-INF/container.xml');
      if(!container)throw new Error('META-INF/container.xml is missing.');
      let packagePath='';
      try{ packagePath=parseEpubContainer(container); }catch(primary){
        const rm=container.match(/<rootfile\b[^>]*\bfull-path\s*=\s*["']([^"']+)["']/i); packagePath=rm?rm[1]:'';
        if(!packagePath)throw primary;
      }
      packagePath=norm('',packagePath);
      const pkg=await zip.text(packagePath);if(!pkg)throw new Error('The EPUB package could not be read.');
      let parsed;
      try{parsed=parseEpubPackage(pkg);}catch(primary){
        const base=dirname(packagePath),manifest=new Map();
        for(const m of pkg.matchAll(/<item\b([^>]*?)(?:\/?>)/gi)){const tag=m[1],id=attr(tag,'id'),href=attr(tag,'href'),media=attr(tag,'media-type'),properties=attr(tag,'properties');if(id&&href)manifest.set(id,{path:href,media,properties});}
        parsed={manifest,spine:[...pkg.matchAll(/<itemref\b([^>]*?)(?:\/?>)/gi)].map(m=>attr(m[1],'idref')).map(id=>manifest.get(id)).filter(x=>x&&(/^(?:application\/xhtml\+xml|text\/html)$/i.test(x.media)||/\.(xhtml?|html?)$/i.test(x.path))),title:strip((pkg.match(/<dc:title\b[^>]*>([\s\S]*?)<\/dc:title>/i)||[])[1]),creator:strip((pkg.match(/<dc:creator\b[^>]*>([\s\S]*?)<\/dc:creator>/i)||[])[1]),coverId:attr((pkg.match(/<meta\b[^>]*\bname\s*=\s*["']cover["'][^>]*>/i)||[])[0]||'','content')};
      }
      const base=dirname(packagePath),manifest=new Map([...parsed.manifest].map(([id,x])=>[id,{...x,path:norm(base,x.path)}]));
      const spine=(parsed.spineIds||parsed.spine.map(x=>[...parsed.manifest.entries()].find(([,v])=>v===x)?.[0]||x.id)).map(id=>manifest.get(id)).filter(Boolean);
      if(!spine.length)throw new Error('No readable chapters were found in this EPUB.');
      const resources=new Map(),styles={};
      // Two-pass resource loading: binaries first, CSS second, so CSS url(...)
      // references can resolve regardless of manifest ordering.
      for(const item of manifest.values()){
        if(/^(?:image\/|font\/|application\/font)/i.test(item.media||'')){const u=await dataUrl(zip,item.path);if(u)resources.set(item.path,u);}
      }
      for(const item of manifest.values()){
        if(/^text\/css$/i.test(item.media||'')){const css=await zip.text(item.path);if(css)styles[item.path]=sanitizeCss(css,dirname(item.path),resources);}
      }
      const chapters=[];
      for(const item of spine){const raw=await zip.text(item.path);if(!raw)continue;chapters.push({title:extractTitle(raw)||`Chapter ${chapters.length+1}`,html:sanitizeHtml(raw,dirname(item.path),resources,styles)});}
      if(!chapters.length)throw new Error('The EPUB chapters could not be read.');
      const title=strip(parsed.title)||name.replace(/\.epub$/i,'')||'Untitled';
      const author=strip(parsed.creator)||'Unknown author';
      let coverItem=parsed.coverId?manifest.get(parsed.coverId):null;
      coverItem=coverItem||[...manifest.values()].find(x=>/cover-image/i.test(x.properties||''))||[...manifest.values()].find(x=>/^image\//i.test(x.media||'')&&/cover/i.test(x.path));
      const cover=coverItem?await dataUrl(zip,coverItem.path):null;
      const bookId=await fingerprintBook(title,author,chapters),existing=books.find(b=>b.id===bookId)||null;
      const book={id:bookId,title,author,type:'epub',chapters,progress:existing?.progress||0,chapter:existing?.chapter||0,scroll:existing?.scroll||0,added:existing?.added||Date.now(),updated:Date.now(),cover:cover||existing?.cover||null,bookmarks:existing?.bookmarks||[],highlights:existing?.highlights||[],notes:existing?.notes||[],pageAnnotations:existing?.pageAnnotations||[],minutes:existing?.minutes||0,readingSeconds:existing?.readingSeconds||0,history:existing?.history||[],page:existing?.page||0,readingUpdated:existing?.readingUpdated||Date.now(),favorite:!!existing?.favorite,folderId:folderId??existing?.folderId??null,deviceUpdated:{...(existing?.deviceUpdated||{}),[deviceId]:Date.now()}};
      await put(book);books=await all();localStorage.setItem('PersonalReaderLastBook',book.id);currentFolderId=folderId??currentFolderId;library();showToast(existing?`“${title}” refreshed.`:`“${title}” added to your library.`);
    }catch(e){console.error('EPUB import failed',e);showToast(`EPUB import failed: ${e?.message||'Unknown error'}`,true);}finally{if(btn){btn.disabled=false;btn.innerHTML=btn.dataset.old||'Add files';}}
  }

  function extractTitle(raw){ return strip((raw.match(/<title[^>]*>([\s\S]*?)<\/title>/i)||[])[1]) || strip((raw.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i)||[])[1]); }

  function syncConfig(){
    try{return {...JSON.parse(localStorage.getItem(SYNC_KEY)||'{}')};}catch{return {};}
  }
  function defaultSyncUrl(){return `${location.origin}/.netlify/functions/sync`;}
  function generateSyncCredentials(){return {url:defaultSyncUrl(),id:crypto.randomUUID().replaceAll('-','').slice(0,16),token:crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-','')}}
  function saveSyncConfig(cfg){localStorage.setItem(SYNC_KEY,JSON.stringify(cfg));}
  function mergeFolders(local, remote){ const byId=new Map((local||[]).map(f=>[f.id,f])); for(const rf of (remote||[])){const lf=byId.get(rf.id); if(!lf || (rf.updated||0)>(lf.updated||0)) byId.set(rf.id,rf);} return [...byId.values()]; }
  function mergeBooks(local, remote){
    const byId=new Map(local.map(b=>[b.id,b]));
    const union=(a,b)=>{const m=new Map();for(const x of (a||[]))m.set(x.id||`${x.chapter}:${x.position||x.text||''}`,x);for(const x of (b||[]))m.set(x.id||`${x.chapter}:${x.position||x.text||''}`,x);return [...m.values()];};
    for(const rb of (remote||[])){
      const lb=byId.get(rb.id); if(!lb){byId.set(rb.id,rb);continue;}
      const lr=lb.readingUpdated||lb.updated||0, rr=rb.readingUpdated||rb.updated||0;
      const readingWinner=rr>lr?rb:lb; const metaWinner=(rb.updated||0)>(lb.updated||0)?rb:lb;
      byId.set(rb.id,{...lb,...metaWinner,chapter:readingWinner.chapter||0,page:readingWinner.page||0,scroll:readingWinner.scroll||0,progress:readingWinner.progress||0,readingUpdated:Math.max(lr,rr),bookmarks:union(lb.bookmarks,rb.bookmarks),highlights:union(lb.highlights,rb.highlights),notes:union(lb.notes,rb.notes),updated:Math.max(lb.updated||0,rb.updated||0)});
    }
    return [...byId.values()];
  }
  async function syncNow(manual=true){
    const cfg=syncConfig();
    if(syncBusy)return;
    if(!cfg.url||!cfg.id||!cfg.token){if(manual)showToast('Sync is not configured. Open Settings → Device sync.',true);return;}
    syncBusy=true;
    try{
      const base=cfg.url.replace(/\/$/,'');
      const headers={'Content-Type':'application/json','X-Sync-Id':cfg.id,'Authorization':`Bearer ${cfg.token}`,'X-Device-Id':deviceId};
      const remoteRes=await fetch(`${base}?sync_id=${encodeURIComponent(cfg.id)}`,{headers,cache:'no-store'});
      if(!remoteRes.ok)throw new Error(`Sync server returned ${remoteRes.status}`);
      const remote=await remoteRes.json();
      books=mergeBooks(books,remote.books||[]);
      folders=mergeFolders(folders,remote.folders||[]);
      for(const b of books)await put(b); for(const f of folders)await putFolder(f);
      const payload={version:2,deviceId,updated:Date.now(),books,folders};
      const putRes=await fetch(base,{method:'PUT',headers,body:JSON.stringify(payload)});
      if(!putRes.ok)throw new Error(`Sync upload returned ${putRes.status}`);
      books=await all();
      if(manual)showToast(`Synced ${books.length} book${books.length===1?'':'s'} — merged, never replaced.`);
      if(current){const fresh=books.find(b=>b.id===current.id);if(fresh){const changed=fresh.chapter!==currentChapter||fresh.page!==currentPage||fresh.scroll!==currentStart;current=fresh;currentChapter=clamp(fresh.chapter||0,0,Math.max(0,current.chapters.length-1));currentPage=fresh.page||0;currentStart=fresh.scroll||0;if(changed)renderReader();}}
    }catch(e){if(manual)showToast(`Sync failed: ${e.message}`,true);}
    finally{syncBusy=false;}
  }
  function scheduleAutoSync(){const cfg=syncConfig();if(cfg.autoSync===false||!cfg.url||!cfg.id||!cfg.token)return;clearTimeout(syncTimer);syncTimer=setTimeout(()=>syncNow(false),900);}
  function syncUI(){
    const cfg=syncConfig();
    const o=overlay(`<div class="modal-head"><div><div class="eyebrow">MULTI-DEVICE</div><h2>Device sync</h2></div><button class="close">×</button></div><p class="muted">The same Sync ID + token connects your devices. Progress uses the newest saved reading event; bookmarks, highlights and notes are union-merged so an offline device cannot erase the other device's annotations.</p><div class="sync-actions"><button class="text-btn" id="generateSync">Create new sync code</button><button class="text-btn" id="copySync">Copy code</button></div><label class="label">Sync endpoint<input class="field" id="syncUrl" value="${esc(cfg.url||defaultSyncUrl())}"></label><label class="label">Sync ID<input class="field" id="syncId" placeholder="Paste the Sync ID" value="${esc(cfg.id||'')}"></label><label class="label">Sync token<input class="field" id="syncToken" type="password" placeholder="Paste the sync token" value="${esc(cfg.token||'')}"></label><div class="setting-row"><div><b>Auto-sync</b><small>Startup + after reading changes.</small></div><button class="switch ${cfg.autoSync!==false?'on':''}" id="autoSync"><span></span></button></div><div class="modal-foot"><button class="text-btn" id="syncNow">Sync now</button><button class="cta" id="saveSync">Save <span>✓</span></button></div>`);
    $('.close',o).onclick=()=>o.remove(); let auto=cfg.autoSync!==false;
    $('#autoSync').onclick=()=>{auto=!auto;$('#autoSync').classList.toggle('on',auto);};
    $('#generateSync').onclick=()=>{const n=generateSyncCredentials();$('#syncUrl').value=n.url;$('#syncId').value=n.id;$('#syncToken').value=n.token;$('#syncToken').type='text';showToast('New sync code created. Copy it to your other device.');};
    $('#copySync').onclick=async()=>{const text=`${$('#syncUrl').value}\nSync ID: ${$('#syncId').value}\nSync token: ${$('#syncToken').value}`;await navigator.clipboard?.writeText(text);showToast('Sync code copied.');};
    const collect=()=>({url:$('#syncUrl').value.trim(),id:$('#syncId').value.trim(),token:$('#syncToken').value,autoSync:auto});
    $('#saveSync').onclick=()=>{const next=collect();saveSyncConfig(next);settings.syncUrl=next.url;settings.syncId=next.id;settings.syncToken=next.token;settings.autoSync=auto;applySettings();o.remove();showToast(next.url&&next.id&&next.token?'Sync configured.':'Sync configuration cleared.');if(next.url&&next.id&&next.token)syncNow(false);};
    $('#syncNow').onclick=()=>{const next=collect();saveSyncConfig(next);o.remove();syncNow(true);};
  }

  function setup(){
    document.body.innerHTML=`<main class="onboarding"><div class="onboarding-orbit"></div><section class="onboarding-card enter"><div class="appmark">PR</div><div class="eyebrow">PERSONAL READER</div><h1>A better place<br><em>for your books.</em></h1><p>A private reading space for EPUBs, built for long sessions, offline use and E‑Ink.</p><div class="setup-points"><span>EPUB</span><span>OFFLINE</span><span>E‑INK</span><span>BOOKMARKS</span><span>NOTES</span><span>TRANSLATION READY</span></div><button class="cta" id="begin">Enter PersonalReader <span>→</span></button><small>Your books stay on this device.</small></section></main>`;
    $('#begin').onclick=()=>{settings.setup=true;applySettings();launchScreen();};
  }

  function launchScreen(){
    const lastId=localStorage.getItem('PersonalReaderLastBook');
    const last=books.find(b=>b.id===lastId)||books.slice().sort((a,b)=>(b.updated||0)-(a.updated||0))[0];
    const recent=books.slice().sort((a,b)=>(b.updated||b.added)-(a.updated||a.added)).slice(0,4);
    const fav=books.filter(b=>b.favorite).length,totalMinutes=Math.floor(books.reduce((n,b)=>n+(b.readingSeconds||0),0)/60);
    document.body.innerHTML=`<main class="launch-screen ambient"><div class="launch-grid"></div><div class="launch-orbit"></div><section class="launch-card enter"><div class="launch-top"><div class="appmark big">PR</div><div><div class="eyebrow">PERSONAL READER</div><div class="launch-version">YOUR PRIVATE READING SPACE</div></div><div class="launch-status">${books.length} BOOK${books.length===1?'':'S'} · ${fav} SAVED</div></div><div class="launch-copy"><span class="launch-kicker">LOCAL · PRIVATE · MULTI-DEVICE READY</span><h1>Welcome<br><em>back.</em></h1><p>${last?`Your next page is waiting in <b>${esc(last.title)}</b>, ${Math.round((last.progress||0)*100)}% complete.`:'Your shelf is empty, but the space is ready for something worth keeping.'}</p></div><div class="launch-actions">${last?`<button class="cta" id="resume">Continue reading <span>→</span></button>`:''}<button class="ghost-cta" id="openLibrary">Open library <span>⌘</span></button></div><div class="launch-panels"><div><small>BOOKS</small><b>${books.length}</b></div><div><small>TIME READ</small><b>${formatDuration(Math.floor(books.reduce((n,b)=>n+(b.readingSeconds||0),0)))}</b></div><div><small>FAVORITES</small><b>${fav}</b></div></div><div class="launch-recent"><div class="section-head mini"><div><span>RECENTLY TOUCHED</span></div></div><div class="mini-shelf">${recent.length?recent.map(b=>`<button class="mini-book" data-launch-read="${b.id}"><span class="mini-cover" style="${b.cover?`background-image:url('${b.cover}')`:''}"></span><b>${esc(b.title)}</b><small>${Math.round((b.progress||0)*100)}%</small></button>`).join(''):`<div class="launch-empty">Import an EPUB from the library to start building your shelf.</div>`}</div></div><div class="launch-meta"><span>OFFLINE FIRST</span><span>ANNOTATION READY</span><span>E‑INK READY</span><span>SYNC OPTIONAL</span></div></section></main>`;
    $('#resume')?.addEventListener('click',()=>read(last.id));$('#openLibrary').onclick=library;$$('[data-launch-read]').forEach(x=>x.onclick=()=>read(x.dataset.launchRead));
  }
  function library(){
    if(!settings.setup)return setup();
    const lastId=localStorage.getItem('PersonalReaderLastBook'),last=books.find(b=>b.id===lastId)||books.slice().sort((a,b)=>(b.updated||0)-(a.updated||0))[0];
    const currentFolder=folders.find(f=>f.id===currentFolderId),children=folderChildren(currentFolderId);
    document.body.innerHTML=`<div class="app-shell library-shell ambient"><div class="ambient-grid"></div><header class="topbar"><button class="brand-button" id="home"><span class="mark">PR</span><span>PersonalReader</span></button><nav class="nav"><button class="nav-btn active" id="libraryTab">Library</button><button class="nav-btn" id="statsTab">Insights</button></nav><div class="top-actions"><button class="round-btn" id="searchBtn" aria-label="Search">⌕</button><button class="round-btn" id="notesBtn" aria-label="Notes">✎</button><button class="round-btn" id="randomBtn" aria-label="Open random book">✦</button><button class="round-btn" id="settingsBtn" aria-label="Settings">⚙</button><button class="cta small" id="import">Add files <span>＋</span></button></div><input id="file" type="file" accept="*/*,.epub,.pdf,.txt,.md,.markdown,.html,.htm,.docx,.cbz" multiple hidden></header><main class="content"><section class="library-hero enter"><div><div class="eyebrow">YOUR LIBRARY / ${books.length?'ACTIVE':'READY'}</div><h1>${currentFolder?esc(currentFolder.name):'A shelf built'}<br><em>${currentFolder?'inside your library.':'around you.'}</em></h1><p class="hero-copy">Keep books and documents arranged your way. Folders stay private, searchable, and easy to revisit.</p><div class="hero-actions"><button class="cta" id="heroImport">Add files <span>＋</span></button><button class="ghost-cta" id="newFolderTop">New folder <span>＋</span></button>${last?`<button class="ghost-cta" id="heroContinue">Continue ${esc(last.title)} <span>→</span></button>`:''}</div></div><div class="hero-stats"><div><strong>${books.length}</strong><span>items</span></div><div><strong>${Math.round(books.reduce((n,b)=>n+(b.progress||0),0)/Math.max(1,books.length)*100)}%</strong><span>avg. read</span></div><div><strong>${folders.length}</strong><span>folders</span></div></div></section><section class="folder-bar"><div class="folder-breadcrumb"><button class="crumb" id="rootCrumb">Library</button>${currentFolder?`<span>›</span><span class="crumb current">${esc(currentFolder.name)}</span>`:''}</div><div class="folder-actions"><button class="folder-btn" id="newFolder">＋ Folder</button>${currentFolder?`<button class="folder-btn danger" id="deleteFolder">Delete folder</button>`:''}</div></section><section class="folder-grid" id="folderGrid">${children.map(f=>`<button class="folder-card enter" data-enter-folder="${f.id}"><span class="folder-icon">▰</span><span><b>${esc(f.name)}</b><small>${books.filter(b=>b.folderId===f.id).length} books · ${folders.filter(x=>x.parentId===f.id).length} folders</small></span><i>›</i></button>`).join('')}</section><section class="library-tooldeck"><div class="search-strip"><span class="search-icon">⌕</span><input id="libraryFilter" placeholder="Search every book in every folder…"><kbd>/</kbd></div><div class="filter-row"><button class="filter-chip active" data-filter="all">All</button><button class="filter-chip" data-filter="progress">In progress</button><button class="filter-chip" data-filter="unread">Unread</button><button class="filter-chip" data-filter="finished">Finished</button><button class="filter-chip" data-filter="favorite">Favorites</button><div class="view-toggle"><button data-view="grid" id="viewGrid">▦</button><button data-view="list" id="viewList">☰</button></div></div></section><section id="continueStrip"></section><section id="libraryBody"></section></main></div>`;
    const openPicker=()=>{const input=$('#file');if(!input){showToast('The file picker is unavailable on this screen.',true);return;}try{input.value='';input.click();}catch(e){console.error(e);showToast('Could not open the file picker.',true);}};$('#import').onclick=openPicker;$('#heroImport').onclick=openPicker;$('#newFolder').onclick=()=>createFolder(currentFolderId);$('#newFolderTop').onclick=()=>createFolder(currentFolderId);$('#deleteFolder')?.addEventListener('click',()=>removeFolder(currentFolderId));$('#rootCrumb').onclick=()=>{currentFolderId=null;library();};$('#file').onchange=async e=>{const fs=[...(e.target.files||[])];e.target.value='';for(const f of fs)await importGeneric(f,currentFolderId);};$('#searchBtn').onclick=searchUI;$('#notesBtn').onclick=notesUI;$('#statsTab').onclick=statsUI;$('#home').onclick=()=>{currentFolderId=null;library();};$('#randomBtn').onclick=()=>{if(!books.length){showToast('Add a book first.');return;}read(books[Math.floor(Math.random()*books.length)].id);};$('#heroContinue')?.addEventListener('click',()=>read(last.id));$('#emptyImport')?.addEventListener('click',openPicker);const folderGrid=$('#folderGrid');if(folderGrid){folderGrid.onclick=e=>{const card=e.target.closest('[data-enter-folder]');if(!card||!folderGrid.contains(card))return;e.preventDefault();e.stopPropagation();const id=String(card.dataset.enterFolder||'');if(!folders.some(f=>f.id===id)){showToast('That folder no longer exists.',true);return;}currentFolderId=id;library();};}const filterInput=$('#libraryFilter');filterInput.oninput=()=>renderLibrary(filterInput.value);$$('[data-filter]').forEach(x=>x.onclick=()=>{settings.filter=x.dataset.filter;applySettings();$$('[data-filter]').forEach(y=>y.classList.toggle('active',y===x));renderLibrary(filterInput.value);});$$('[data-view]').forEach(x=>x.onclick=()=>{settings.view=x.dataset.view;applySettings();renderLibrary(filterInput.value);});renderLibrary();updateContinueStrip(last);
  }
  function libraryShortcut(e){if(!document.querySelector('.library-shell'))return;if(e.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement?.tagName)){e.preventDefault();$('#libraryFilter')?.focus();}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('#libraryFilter')?.focus();}}
  function updateContinueStrip(last){const root=$('#continueStrip');if(!root)return;const recent=books.filter(b=>(b.progress||0)>0&&b.progress<.999).slice().sort((a,b)=>(b.updated||0)-(a.updated||0)).slice(0,3);root.innerHTML=last?`<div class="continue-deck enter"><div><span class="eyebrow">CONTINUE WHERE YOU LEFT OFF</span><h2>${esc(last.title)}</h2><p>${esc(folderPath(last.folderId)||'Library')}</p></div><div class="continue-meter"><div class="ring" style="--p:${Math.round((last.progress||0)*360)}deg"><span>${Math.round((last.progress||0)*100)}%</span></div><button class="cta" id="continueNow">Resume <span>→</span></button></div></div>${recent.length?`<div class="recent-rail"><div class="section-head mini"><div><span>RECENTLY READ</span></div></div><div class="recent-row">${recent.map(b=>`<button class="recent-chip" data-recent="${b.id}"><span>${esc(b.title.slice(0,1))}</span><div><b>${esc(b.title)}</b><small>${Math.round((b.progress||0)*100)}% · ${esc(folderPath(b.folderId)||'Library')}</small></div></button>`).join('')}</div></div>`:''}`:'';$('#continueNow')?.addEventListener('click',()=>read(last.id));$$('[data-recent]').forEach(x=>x.onclick=()=>read(x.dataset.recent));}
  function renderLibrary(filter=''){
    const root=$('#libraryBody');if(!root)return;const q=filter.trim().toLocaleLowerCase();
    const scoped=q?books:books.filter(b=>(b.folderId||null)===(currentFolderId||null));
    let list=scoped.filter(b=>{const hay=`${b.title} ${b.author} ${folderPath(b.folderId)} ${b.type||''}`.toLocaleLowerCase();const match=!q||hay.includes(q);const f=settings.filter||'all';const state=f==='progress'?(b.progress>0&&b.progress<.999):f==='unread'?(b.progress<=0):f==='finished'?(b.progress>=.999):f==='favorite'?!!b.favorite:true;return match&&state;});
    if(settings.sort==='title')list.sort((a,b)=>a.title.localeCompare(b.title));else if(settings.sort==='progress')list.sort((a,b)=>(b.progress||0)-(a.progress||0));else list.sort((a,b)=>(b.updated||b.added)-(a.updated||a.added));
    root.dataset.view=settings.view||'grid';
    const activeFolder=folders.find(f=>f.id===currentFolderId);const scopeLabel=q?'SEARCH RESULTS':activeFolder?`FOLDER · ${activeFolder.name}`:'SHELF';
    root.innerHTML=`<div class="section-head"><div><span>${esc(scopeLabel)}</span><b>${list.length}</b></div><div class="section-actions"><select class="sort-select" id="sortSelect"><option value="recent">Recently read</option><option value="title">Title</option><option value="progress">Progress</option></select></div></div>${list.length?`<div class="book-grid ${settings.view==='list'?'list-view':''}">${list.map(card).join('')}</div>`:`<div class="empty-state enter"><div class="empty-icon">✦</div><h2>${q?'No matches here.':activeFolder?'This folder is empty.':books.length?'Your root shelf is empty.':'Your shelf is empty.'}</h2><p>${q?'Search checks titles, authors, types and folder paths across the whole library.':'Add a document here or create a folder to organize it.'}</p><button class="cta" id="emptyImport">Add files <span>＋</span></button></div>`}`;
    $('#sortSelect').value=settings.sort;$('#sortSelect').onchange=e=>{settings.sort=e.target.value;applySettings();renderLibrary(filter);};$('#emptyImport')?.addEventListener('click',()=>$('#file')?.click());
    $$('[data-read]',root).forEach(x=>x.onclick=()=>read(x.dataset.read));$$('[data-menu]',root).forEach(x=>x.onclick=()=>bookMenu(x.dataset.menu));
    $$('[data-fav]',root).forEach(x=>x.onclick=async()=>{const b=books.find(y=>y.id===x.dataset.fav);if(!b)return;b.favorite=!b.favorite;b.updated=Date.now();await put(b);books=await all();renderLibrary(filter);});
    $$('[data-move]',root).forEach(x=>x.onclick=()=>moveBookUI(books.find(b=>b.id===x.dataset.move)));
  }





  function card(b){const p=Math.round((b.progress||0)*100),initial=esc((b.title||'?').slice(0,1).toUpperCase()),fav=!!b.favorite,time=formatDuration(b.readingSeconds||0),kind=(b.type||'epub').toUpperCase();return `<article class="book-card enter ${fav?'is-favorite':''}"><button class="cover-art" data-read="${b.id}"><span class="cover-glow"></span>${b.cover?`<img src="${b.cover}" alt="">`:''}<span class="cover-shade"></span><span class="cover-initial">${initial}</span><span class="cover-title">${esc(b.title)}</span><span class="cover-badge">${kind} · ${p>=.999?'FINISHED':p?'READING':'NEW'}</span></button><div class="book-info"><div class="book-line"><button class="book-title" data-read="${b.id}">${esc(b.title)}</button><button class="favorite-btn ${fav?'on':''}" data-fav="${b.id}" aria-label="${fav?'Remove from favorites':'Add to favorites'}">${fav?'★':'☆'}</button></div><div class="author">${esc(b.author||kind)}</div><div class="folder-label">${esc(folderPath(b.folderId)||'Library')}</div><div class="progress-row"><div class="progress-track"><i style="width:${p}%"></i></div><span>${p}%</span></div><div class="book-meta-line"><span>${time} read</span><span>${b.chapters?.length||1} section${(b.chapters?.length||1)===1?'':'s'}</span></div><div class="card-actions"><button class="read-link" data-read="${b.id}">${p?'Continue':'Start'} <span>→</span></button><button class="more" data-menu="${b.id}" aria-label="Book menu">•••</button><button class="move-link" data-move="${b.id}" aria-label="Move book">↗</button></div></div></article>`;}

  function downloadText(name,text,type='application/json'){const blob=new Blob([text],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  async function exportBackup(){try{await stopReadingTimer(true);const payload={format:'PersonalReader backup',version:1,exportedAt:new Date().toISOString(),settings:{...settings,aiKey:'',syncToken:''},folders:await allFolders(),books:(await all()).map(b=>({...b,fileBlob:undefined}))};downloadText(`PersonalReader-backup-${new Date().toISOString().slice(0,10)}.json`,JSON.stringify(payload),'application/json');showToast('Backup exported.');}catch(e){console.error(e);showToast('Could not create a backup.',true);}}
  async function importBackup(file){if(!file)return;try{const raw=await file.text();const data=JSON.parse(raw);if(data?.format!=='PersonalReader backup'||!Array.isArray(data.books)||!Array.isArray(data.folders))throw new Error('This is not a PersonalReader backup.');if(!confirm(`Restore ${data.books.length} books and ${data.folders.length} folders? Existing items with the same IDs will be replaced.`))return;for(const f of data.folders){if(f?.id&&f.name)await putFolder({...f,parentId:f.parentId||null});}for(const b of data.books){if(b?.id&&b.title&&Array.isArray(b.chapters))await put({...b,fileBlob:null});}books=await all();folders=await allFolders();library();showToast('Backup restored.');}catch(e){console.error(e);showToast(`Backup restore failed: ${e.message||'Invalid backup.'}`,true);}}

  function themeSwatches(theme){
    const cp=settings.customPalette||{};
    const fallback={
      obsidian:'#0b0d10',paper:'#f3f0e8',nord:'#2e3440',dracula:'#282a36',solarized:'#002b36',gruvbox:'#282828',catppuccin:'#1e1e2e',rosepine:'#191724',cyber:'#070a10',everforest:'#2d353b',kanagawa:'#1f1f28',tokyo:'#16161e',midnight:'#080b14',sepia:'#e9dcc8',custom:cp.bg||'#0c1119'
    };
    return {bg:fallback[theme]||'#0b0d10', accent:theme==='custom'?(cp.accent||'#78d9ff'):'var(--accent)'};
  }
  function animateUIChange(mutator, opts={}){
    const reduced=settings.eink || window.matchMedia('(prefers-reduced-motion:reduce)').matches;
    if(reduced || typeof mutator!=='function'){mutator?.();return;}
    const run=()=>{mutator();};
    if(document.startViewTransition){
      try{
        const vt=document.startViewTransition(run);
        vt.ready?.catch?.(()=>{}); vt.finished?.catch?.(()=>{});
        return;
      }catch{}
    }
    const root=document.documentElement;
    const oldTheme=root.dataset.theme||settings.theme||'obsidian';
    const oldSwatch=themeSwatches(oldTheme);
    const veil=document.createElement('div');
    veil.className='theme-transition-veil';
    veil.style.setProperty('--theme-old-bg',oldSwatch.bg);
    veil.style.setProperty('--theme-old-accent',oldSwatch.accent);
    veil.innerHTML='<div class="theme-transition-glow"></div>';
    root.appendChild(veil);
    run();
    const sw=themeSwatches(settings.theme||'obsidian');
    veil.style.setProperty('--theme-new-bg',sw.bg);
    veil.style.setProperty('--theme-new-accent',sw.accent);
    if((settings.theme||'obsidian')==='custom' && settings.customWallpaper) veil.dataset.custom='1';
    requestAnimationFrame(()=>requestAnimationFrame(()=>veil.classList.add('reveal')));
    setTimeout(()=>veil.remove(),1100);
  }

  function settingsUI(){
    const o=overlay(`<div class="modal-head"><div><div class="eyebrow">PERSONALIZE</div><h2>Settings</h2></div><button class="close" aria-label="Close">×</button></div><div class="settings-list"><div class="setting-row"><div><b>Appearance</b><small>Choose the atmosphere of PersonalReader.</small></div><select class="field" id="theme"><option value="obsidian">Obsidian</option><option value="paper">Paper</option><option value="nord">Nord Frost</option><option value="dracula">Dracula</option><option value="solarized">Solarized</option><option value="gruvbox">Gruvbox</option><option value="catppuccin">Catppuccin</option><option value="rosepine">Rosé Pine</option><option value="cyber">Cyber Grid</option><option value="everforest">Everforest</option><option value="kanagawa">Kanagawa</option><option value="tokyo">Tokyo Night</option><option value="midnight">Midnight Ink</option><option value="sepia">Sepia Atelier</option><option value="custom">Custom · Aero Glass</option></select></div><div class="setting-row custom-theme-row"><div><b>Custom background</b><small>Upload a wallpaper and tune the glass effect.</small></div><button class="text-btn" id="customTheme">Configure</button></div><div class="setting-row"><div><b>E‑Ink / performance mode</b><small>High contrast, no unnecessary motion and simplified rendering.</small></div><button class="switch ${settings.eink?'on':''}" id="eink"><span></span></button></div><div class="setting-row"><div><b>Reader mode</b><small>Continuous scroll or real page-by-page navigation.</small></div><select class="field" id="readerMode"><option value="scroll">Continuous scroll</option><option value="paged">Book pages / swipe</option></select></div><div class="setting-row"><div><b>Device layout</b><small>Phone, tablet / E‑Ink, or automatic sizing.</small></div><select class="field" id="deviceMode"><option value="auto">Auto</option><option value="phone">Phone</option><option value="tablet">Tablet / E‑Ink</option></select></div><div class="setting-row"><div><b>Reading size</b><small id="fontHelp">${settings.font}px</small></div><div class="stepper"><button id="fontDown">−</button><b id="fontVal">${settings.font}px</b><button id="fontUp">＋</button></div></div><div class="setting-row"><div><b>Line spacing</b><small>Controlled by PersonalReader rather than the EPUB.</small></div><select class="field" id="line"><option value="1.45">Compact</option><option value="1.65">Comfortable</option><option value="1.85">Relaxed</option><option value="2.05">Airy</option></select></div><div class="setting-row"><div><b>Pen auto-annotation</b><small>On supported tablets, pen input automatically enters ink mode; fingers remain navigation.</small></div><button class="switch ${settings.penAuto!==false?'on':''}" id="penAuto"><span></span></button></div><div class="setting-row"><div><b>Annotation input</b><small>Choose whether annotations are made with a pen only or with finger + pen.</small></div><select class="field" id="annotationInput"><option value="pen">Pen only · finger navigates</option><option value="both">Finger + pen · draw freely</option></select></div><div class="setting-row"><div><b>Read-aloud profile</b><small>Slower literary pacing; dialogue receives extra breath between lines.</small></div><select class="field" id="ttsRate"><option value="0.72">Leisurely</option><option value="0.82">Story</option><option value="0.88">Literary</option><option value="1">Natural</option></select></div><div class="setting-row"><div><b>Translation</b><small>Optional compatible translation endpoint. Your key stays local.</small></div><button class="text-btn" id="translationSetup">Configure</button></div><div class="setting-row"><div><b>Local backup</b><small>Export library metadata, folders, progress and annotations to a portable JSON backup. Original source files are not included.</small></div><div class="backup-actions"><button class="text-btn" id="exportBackup">Export</button><label class="text-btn backup-import">Restore<input id="restoreBackup" type="file" accept="application/json,.json" hidden></label></div></div><div class="setting-row"><div><b>Device sync</b><small>Merge progress by newest reading event and union-merge annotations.</small></div><button class="text-btn" id="syncSetup">Configure</button></div></div><div class="modal-foot"><button class="text-btn" id="resetSettings">Reset</button><button class="cta" id="saveSettings">Done <span>→</span></button></div>`);
    o.dataset.settingsModal='true';
    $('#theme',o).value=settings.theme||'obsidian';$('#line',o).value=String(settings.line||1.65);$('#ttsRate',o).value=String(settings.ttsRate||0.88);$('#readerMode',o).value=settings.readerMode||'scroll';$('#deviceMode',o).value=settings.deviceMode||'auto';$('#annotationInput',o).value=settings.annotationInput||'pen';
    $('.close',o).onclick=()=>o.remove();
    $('#eink',o).onclick=()=>{settings.eink=!settings.eink;applySettings();$('#eink',o).classList.toggle('on',settings.eink);if(current)renderReader();showToast(settings.eink?'E‑Ink mode enabled.':'Motion and color restored.');};
    $('#penAuto',o).onclick=()=>{settings.penAuto=!settings.penAuto;applySettings();$('#penAuto',o).classList.toggle('on',settings.penAuto);};$('#annotationInput',o).onchange=e=>{settings.annotationInput=e.target.value;applySettings();};
    $('#fontDown',o).onclick=()=>{settings.font=clamp(settings.font-1,13,30);$('#fontVal',o).textContent=`${settings.font}px`;$('#fontHelp',o).textContent=`${settings.font}px`;applySettings();if(current)renderReader();};
    $('#fontUp',o).onclick=()=>{settings.font=clamp(settings.font+1,13,30);$('#fontVal',o).textContent=`${settings.font}px`;$('#fontHelp',o).textContent=`${settings.font}px`;applySettings();if(current)renderReader();};
    $('#theme',o).onchange=e=>{settings.theme=e.target.value;applySettings();};
    $('#line',o).onchange=e=>{settings.line=+e.target.value;applySettings();if(current)renderReader();};$('#ttsRate',o).onchange=e=>{settings.ttsRate=+e.target.value;applySettings();};
    $('#readerMode',o).onchange=e=>{settings.readerMode=e.target.value;currentPage=0;currentStart=0;applySettings();if(current)renderReader();};
    $('#deviceMode',o).onchange=e=>{settings.deviceMode=e.target.value;applySettings();if(current)renderReader();};
    $('#translationSetup',o).onclick=()=>translationSettingsUI(o);$('#syncSetup',o).onclick=()=>syncUI(o);$('#exportBackup',o).onclick=exportBackup;$('#restoreBackup',o).onchange=e=>importBackup(e.target.files?.[0]);
    $('#resetSettings',o).onclick=()=>{settings={...DEFAULTS,setup:true};applySettings();o.remove();settingsUI();if(current)renderReader();};
    $('#saveSettings',o).onclick=()=>{applySettings();o.remove();if(current)renderReader();else library();};
  }

  function readWallpaper(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onerror=()=>reject(r.error);r.onload=()=>{const img=new Image();img.onload=()=>{const max=1800,scale=Math.min(1,max/Math.max(img.width,img.height));const c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));c.getContext('2d').drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',.82));};img.onerror=reject;img.src=String(r.result);};r.readAsDataURL(file);});}

  function customThemeUI(){const o=overlay(`<div class="modal-head"><div><div class="eyebrow">CUSTOM LOOK</div><h2>Your background</h2></div><button class="close">×</button></div><p class="muted">Choose a local image for a personalized background.</p><label class="custom-upload"><input id="wallpaperFile" type="file" accept="image/*" hidden><span>Choose wallpaper</span><small>${settings.customWallpaper?'Background selected':'No background selected'}</small></label><label class="label">Custom mode<select class="field" id="wallTone"><option value="dark" ${settings.customTone!=='light'?'selected':''}>Dark · cinematic</option><option value="light" ${settings.customTone==='light'?'selected':''}>Light · paper</option></select></label><label class="label">Blur<input class="range" id="wallBlur" type="range" min="0" max="40" value="${+settings.customBlur||22}"></label><label class="label">Mica strength<input class="range" id="wallMica" type="range" min="0" max="100" value="${+settings.customMica||38}"></label><label class="label">Background opacity<input class="range" id="wallOpacity" type="range" min="25" max="100" value="${+settings.customOpacity||52}"></label><div class="modal-foot"><button class="text-btn" id="clearWallpaper">Remove image</button><button class="cta" id="saveCustom">Save</button></div>`);$('.close',o).onclick=()=>o.remove();$('#wallpaperFile',o).onchange=e=>{const f=e.target.files?.[0];if(!f)return;readWallpaper(f).then(async data=>{$('.custom-upload small',o).textContent='Analyzing colors…';o.dataset.wallpaper=data;o.dataset.palette='';o.dataset.paletteTone=$('#wallTone',o).value;const pal=await deriveWallpaperPalette(data,$('#wallTone',o).value);o.dataset.palette=pal?JSON.stringify(pal):'';$('.custom-upload small',o).textContent=pal?`Wallpaper selected · ${pal.accent} accent`:'Background selected';}).catch(()=>showToast('That image could not be used.',true));};$('#wallTone',o).onchange=()=>{if(o.dataset.wallpaper){o.dataset.palette='';o.dataset.paletteTone='';$('.custom-upload small',o).textContent='Tone changed · analyzing colors…';deriveWallpaperPalette(o.dataset.wallpaper,$('#wallTone',o).value).then(p=>{if(!o.isConnected)return;o.dataset.palette=p?JSON.stringify(p):'';o.dataset.paletteTone=$('#wallTone',o).value;$('.custom-upload small',o).textContent=p?`Wallpaper selected · ${p.accent} accent`:'Background selected';});}};$('#clearWallpaper',o).onclick=()=>{o.dataset.wallpaper='';o.dataset.palette='';o.dataset.paletteTone='';$('.custom-upload small',o).textContent='No background selected';};$('#saveCustom',o).onclick=async()=>{settings.customTone=$('#wallTone',o).value;settings.customBlur=+$('#wallBlur',o).value;settings.customMica=+$('#wallMica',o).value;settings.customOpacity=+$('#wallOpacity',o).value;settings.theme='custom';if('wallpaper'in o.dataset){settings.customWallpaper=o.dataset.wallpaper;let pal=null;if(o.dataset.palette && o.dataset.paletteTone===settings.customTone){try{pal=JSON.parse(o.dataset.palette)}catch{pal=null;}}if(settings.customWallpaper&&!pal)pal=await deriveWallpaperPalette(settings.customWallpaper,settings.customTone);settings.customPalette=pal||null;settings.customPaletteSource=settings.customWallpaper?await digestHex(settings.customWallpaper):'';}else if(settings.customWallpaper){const source=await digestHex(settings.customWallpaper);if(source!==settings.customPaletteSource||!settings.customPalette){settings.customPalette=await deriveWallpaperPalette(settings.customWallpaper,settings.customTone)||null;settings.customPaletteSource=source;}}else{settings.customWallpaper='';settings.customPalette=null;settings.customPaletteSource='';}customPaletteEpoch++;applySettings();o.remove();if(current)renderReader();else library();showToast(settings.customPalette?'Custom theme palette updated from wallpaper.':'Custom theme saved.');};}
  function translationSettingsUI(parent){
    const o=overlay(`<div class="modal-head"><div><div class="eyebrow">TRANSLATION</div><h2>Translation engine</h2></div><button class="close" aria-label="Close">×</button></div><p class="muted">Only the chapter text you choose is sent to the endpoint you configure.</p><label class="label">Compatible translation endpoint<input class="field" id="aiEndpoint" placeholder="https://your-endpoint/v1/chat/completions" value="${esc(settings.aiEndpoint)}"></label><label class="label">Model<input class="field" id="aiModel" value="${esc(settings.aiModel||'gpt-4.1-mini')}"></label><label class="label">API key<input class="field" id="aiKey" type="password" value="${esc(settings.aiKey||'')}" placeholder="Stored only on this device"></label><div class="modal-foot"><button class="text-btn close2">Cancel</button><button class="cta" id="saveAI">Save <span>✓</span></button></div>`);
    $('.close',o).onclick=()=>o.remove();$('.close2',o).onclick=()=>o.remove();
    $('#saveAI',o).onclick=()=>{settings.aiEndpoint=$('#aiEndpoint',o).value.trim();settings.aiModel=$('#aiModel',o).value.trim()||'gpt-4.1-mini';settings.aiKey=$('#aiKey',o).value;applySettings();o.remove();showToast(settings.aiEndpoint?'Translation configured.':'Translation configuration cleared.');};
  }

  function searchUI(){const o=overlay(`<div class="modal-head"><div><div class="eyebrow">LIBRARY SEARCH</div><h2>Find a book</h2></div><button class="close" aria-label="Close">×</button></div><input class="search-input" id="searchInput" placeholder="Title or author…"><div id="searchResults" class="search-results"></div>`);$('.close',o).onclick=()=>o.remove();const input=$('#searchInput',o);const render=()=>{$('#searchResults',o).innerHTML=books.filter(b=>`${b.title} ${b.author}`.toLowerCase().includes(input.value.toLowerCase())).map(b=>`<button class="search-result" data-id="${b.id}"><span>${esc(b.title)}</span><small>${esc(b.author)}</small></button>`).join('')||'<p class="muted">No books found.</p>';$$('[data-id]',o).forEach(x=>x.onclick=()=>{o.remove();read(x.dataset.id);});};input.oninput=render;render();setTimeout(()=>input.focus(),50);}
  function statsUI(){const words=books.reduce((n,b)=>n+b.chapters.reduce((x,c)=>x+strip(c.html).split(/\s+/).filter(Boolean).length,0),0),finished=books.filter(b=>(b.progress||0)>=.999).length;const o=overlay(`<div class="modal-head"><div><div class="eyebrow">READING DATA</div><h2>Your insights</h2></div><button class="close">×</button></div><div class="stat-grid"><div><strong>${books.length}</strong><span>Books</span></div><div><strong>${finished}</strong><span>Finished</span></div><div><strong>${Math.round(words/1000)}k</strong><span>Words</span></div><div><strong>${formatDuration(Math.floor(books.reduce((n,b)=>n+(b.readingSeconds||0),0)))}</strong><span>Read time</span></div></div><div class="insight-list"><div><span>Library progress</span><b>${Math.round(books.reduce((n,b)=>n+(b.progress||0),0)/Math.max(1,books.length)*100)}%</b></div><div><span>Bookmarks</span><b>${books.reduce((n,b)=>n+(b.bookmarks?.length||0),0)}</b></div><div><span>Highlights</span><b>${books.reduce((n,b)=>n+(b.highlights?.length||0),0)}</b></div><div><span>Notes</span><b>${books.reduce((n,b)=>n+(b.notes?.length||0),0)}</b></div></div>`);$('.close',o).onclick=()=>o.remove();}
  function bookMenu(id){const b=books.find(x=>x.id===id);const o=overlay(`<div class="modal-head"><div><div class="eyebrow">BOOK</div><h2>${esc(b.title)}</h2><p class="muted">${esc(b.author)}</p></div><button class="close">×</button></div><div class="menu-actions"><button id="edit">Edit metadata <span>→</span></button><button id="reset">Reset progress <span>↺</span></button><button class="danger" id="remove">Remove from library <span>×</span></button></div>`);$('.close',o).onclick=()=>o.remove();$('#edit',o).onclick=()=>editMetadata(b,o);$('#reset',o).onclick=async()=>{b.progress=0;b.chapter=0;b.page=0;b.updated=Date.now();b.readingUpdated=Date.now();await put(b);books=await all();o.remove();library();};$('#remove',o).onclick=async()=>{if(confirm(`Remove “${b.title}” from your library?`)){await del(id);books=await all();o.remove();library();}};}
  function editMetadata(b,o){o.querySelector('.modal').innerHTML=`<div class="modal-head"><div><div class="eyebrow">BOOK DETAILS</div><h2>Edit metadata</h2></div><button class="close">×</button></div><label class="label">Title<input class="field" id="title" value="${esc(b.title)}"></label><label class="label">Author<input class="field" id="author" value="${esc(b.author)}"></label><div class="modal-foot"><button class="text-btn close2">Cancel</button><button class="cta" id="save">Save changes <span>→</span></button></div>`;$('.close',o).onclick=()=>o.remove();$('.close2',o).onclick=()=>o.remove();$('#save',o).onclick=async()=>{b.title=$('#title',o).value.trim()||'Untitled';b.author=$('#author',o).value.trim()||'Unknown author';b.updated=Date.now();await put(b);books=await all();o.remove();library();};}
  function showToast(text,error=false){document.querySelector('.toast')?.remove();document.body.insertAdjacentHTML('beforeend',`<div class="toast ${error?'error':''}">${esc(text)}</div>`);setTimeout(()=>document.querySelector('.toast')?.remove(),4200);}

  function readerContent(b,index){
    const bg=settings.theme==='paper'?'#fbfaf6':'var(--reader-paper)',fg='var(--reader-ink)';
    if(b.type==='pdf'&&b.fileBlob){const url=URL.createObjectURL(b.fileBlob);setTimeout(()=>{if(!document.querySelector(`.pdf-frame[src=\"${CSS.escape(url)}\"]`))URL.revokeObjectURL(url);},0);return `<article class="reader-article pdf-article" style="--reader-bg:${bg};--reader-fg:${fg}"><section class="reader-book-open"><div class="reader-cover-frame pdf-mark">PDF</div><div class="reader-book-open-meta"><span class="eyebrow">NOW READING</span><h1>${esc(b.title)}</h1><p>PDF document</p></div></section><iframe class="pdf-frame" src="${url}" title="${esc(b.title)}"></iframe><div class="pdf-fallback"><p>If the embedded PDF viewer is unavailable on this device, open the document directly.</p><a class="cta small" href="${url}" target="_blank" rel="noopener">Open PDF</a></div></article>`;}
    const intro=index===0?`<section class="reader-book-open" aria-label="Book cover"><div class="reader-cover-frame">${b.cover?`<img src="${esc(b.cover)}" alt="Book cover">`:`<div class="reader-cover-fallback">${esc((b.title||'?').slice(0,1).toUpperCase())}</div>`}</div><div class="reader-book-open-meta"><span class="eyebrow">NOW READING</span><h1>${esc(b.title)}</h1><p>${esc(b.author||'')}</p></div></section>`:'';
    return `<article class="reader-article" style="--reader-bg:${bg};--reader-fg:${fg}">${intro}<div class="reader-flow">${b.chapters[index]?.html||'<p>This section is empty.</p>'}</div></article>`;
  }

  function formatDuration(totalSeconds){
    const sec=Math.max(0,Math.floor(totalSeconds||0)), h=Math.floor(sec/3600), m=Math.floor((sec%3600)/60), s=sec%60;
    return h?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  }
  function currentReadingSeconds(){
    return (current?.readingSeconds||0)+(readingStartedAt&&!readingPaused?Math.max(0,(Date.now()-readingStartedAt)/1000):0);
  }
  function formatClock(d=new Date()){return d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});}
  function updateReadingClock(){
    const el=$('#readingClock'); const wall=$('#wallClock'); if(wall)wall.textContent=formatClock(); if(!el||!current)return;
    const live=Math.floor(currentReadingSeconds());
    const total=Math.floor((current.readingSeconds||0)+(readingStartedAt&&!readingPaused?Math.max(0,(Date.now()-readingStartedAt)/1000):0));el.textContent=`Reading ${formatDuration(live)} · Total ${formatDuration(total)}`;
  }
  function startReadingTimer(){
    if(!current)return;
    if(!readingStartedAt)readingStartedAt=Date.now();
    readingPaused=false; readingLastCheckpointAt=Date.now();
    clearInterval(readingTickTimer); readingTickTimer=setInterval(()=>{updateReadingClock();if(Date.now()-readingLastCheckpointAt>=15000)checkpointReadingTime();},1000);
    updateReadingClock();
  }
  async function checkpointReadingTime(){
    if(!current||!readingStartedAt)return;
    const elapsed=Math.floor(Math.max(0,Date.now()-readingStartedAt)/1000);
    if(elapsed<1)return;
    current.readingSeconds=(current.readingSeconds||0)+elapsed; current.minutes=Math.floor(current.readingSeconds/60);
    readingStartedAt=Date.now(); readingLastCheckpointAt=Date.now(); current.updated=Date.now(); current.readingUpdated=current.updated;
    current.deviceUpdated={...(current.deviceUpdated||{}),[deviceId]:current.updated}; await put(current); scheduleAutoSync(); updateReadingClock();
  }
  async function stopReadingTimer(persist=true){
    if(!readingStartedAt)return;
    const elapsed=Math.max(0,(Date.now()-readingStartedAt)/1000);
    if(current)current.readingSeconds=(current.readingSeconds||0)+Math.floor(elapsed);
    readingStartedAt=0; readingLastCheckpointAt=0; readingPaused=false; clearInterval(readingTickTimer); readingTickTimer=0; updateReadingClock();
    if(current&&persist){current.minutes=Math.floor(current.readingSeconds/60);current.updated=Date.now();current.readingUpdated=Date.now();current.deviceUpdated={...(current.deviceUpdated||{}),[deviceId]:current.updated};await put(current);scheduleAutoSync();}
  }
  async function pauseReadingTimer(){if(readingStartedAt){await stopReadingTimer(true);}}
  function resumeReadingTimer(){if(current&&!readingStartedAt&&!readingPaused)startReadingTimer();}
  function read(id){current=books.find(b=>b.id===id);if(!current||!Array.isArray(current.chapters)||!current.chapters.length){showToast('This document is unavailable or incomplete.',true);return;}stopTTS();localStorage.setItem('PersonalReaderLastBook',id);currentChapter=clamp(current.chapter||0,0,Math.max(0,current.chapters.length-1));currentPage=Math.max(0,current.page||0);currentStart=current.scroll||0;readingStartedAt=Date.now();readingPaused=false;renderReader();startReadingTimer();scheduleAutoSync();}
  function pageMetrics(){const v=$('#readerViewport'),a=$('.reader-article',v||document);if(!v||!a||settings.readerMode!=='paged')return{count:1,width:1,height:1};return{count:Math.max(1,Number(a.dataset.pageCount||1)),width:Math.max(1,v.clientWidth),height:Math.max(1,v.clientHeight)};}
  function layoutPagedReader(preserve=true){
    const v=$('#readerViewport'),stage=$('.reader-page-stage',v||document),a=$('.reader-article',stage||document);
    if(!v||!a||!stage)return;
    if(settings.readerMode!=='paged'){
      a.removeAttribute('data-page-count');a.removeAttribute('data-page-stride');a.classList.remove('pagination-measuring');
      a.style.cssText='';stage.style.cssText='';return;
    }
    const width=Math.max(1,v.clientWidth),height=Math.max(1,v.clientHeight),gutter=Math.max(12,parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--reader-gutter'))||24);
    const usableHeight=Math.max(160,height-78);

    // Measure the chapter as a normal single-column document first. We deliberately
    // keep this phase separate from the final paginator so the page geometry is never
    // polluted by an old transform/column count.
    a.classList.add('pagination-measuring');
    stage.style.cssText='position:absolute!important;left:0!important;top:0!important;width:100%!important;height:100%!important;overflow:hidden!important;transform:none!important;';
    a.style.setProperty('box-sizing','border-box','important');
    a.style.setProperty('position','relative','important');
    a.style.setProperty('inset','auto','important');
    a.style.setProperty('width',`${Math.max(1,width-2*gutter)}px`,'important');
    a.style.setProperty('height','auto','important');
    a.style.setProperty('min-height','0','important');
    a.style.setProperty('padding',`32px ${gutter}px 46px`,'important');
    a.style.setProperty('column-count','1','important');
    a.style.setProperty('column-width','auto','important');
    a.style.setProperty('column-gap','0','important');
    a.style.setProperty('column-fill','auto','important');
    a.style.setProperty('transform','none','important');
    a.style.setProperty('overflow','visible','important');
    a.style.setProperty('contain','none','important');
    const natural=Math.max(1,a.scrollHeight);
    const estimate=Math.max(1,Math.ceil(natural/usableHeight));

    a.classList.remove('pagination-measuring');

    // Exact page geometry. A page is viewport-wide; the article width includes
    // all columns, their gutters, and its own left/right padding exactly once.
    const pageWidth=width;
    const columnWidth=Math.max(1,width-2*gutter);
    const columnGap=Math.max(0,2*gutter);
    const articleWidth=Math.max(width,estimate*pageWidth);
    const measuredPageCount=Math.max(1,estimate);

    stage.style.setProperty('position','absolute','important');
    stage.style.setProperty('left','0','important');
    stage.style.setProperty('top','0','important');
    stage.style.setProperty('width',`${articleWidth}px`,'important');
    stage.style.setProperty('height',`${height}px`,'important');
    stage.style.setProperty('overflow','visible','important');
    stage.style.setProperty('will-change','transform','important');
    stage.style.setProperty('transform-origin','left top','important');
    stage.style.setProperty('--paged-stage-width',`${articleWidth}px`,'important');

    a.style.setProperty('box-sizing','border-box','important');
    a.style.setProperty('position','relative','important');
    a.style.setProperty('inset','auto','important');
    a.style.setProperty('margin','0','important');
    a.style.setProperty('width',`${articleWidth}px`,'important');
    a.style.setProperty('height',`${height}px`,'important');
    a.style.setProperty('min-height','0','important');
    a.style.setProperty('padding',`32px ${gutter}px 46px`,'important');
    a.style.setProperty('column-count',String(measuredPageCount),'important');
    a.style.setProperty('column-width',`${columnWidth}px`,'important');
    a.style.setProperty('column-gap',`${columnGap}px`,'important');
    a.style.setProperty('column-fill','auto','important');
    a.style.setProperty('transform','none','important');
    a.style.setProperty('overflow','visible','important');
    a.style.setProperty('contain','none','important');

    a.dataset.pageCount=String(measuredPageCount);
    a.dataset.pageStride=String(pageWidth);
    a.dataset.pageWidth=String(pageWidth);
    a.dataset.pageGutter=String(gutter);
    a.style.setProperty('--paged-column-width',`${columnWidth}px`,'important');
    a.style.setProperty('--paged-column-gap',`${columnGap}px`,'important');
    a.style.setProperty('--paged-article-width',`${articleWidth}px`,'important');
    a.style.setProperty('--paged-stage-width',`${articleWidth}px`,'important');
    currentPage=clamp(preserve?currentPage:0,0,measuredPageCount-1);
    requestAnimationFrame(()=>applyPageTransform('instant'));
  }

  function applyPageTransform(behavior='auto'){
    const v=$('#readerViewport'),stage=$('.reader-page-stage',v||document),a=$('.reader-article',stage||document);
    if(!v||!stage||!a||settings.readerMode!=='paged')return;
    const stride=Math.max(1,Number(a.dataset.pageStride)||Math.max(1,v.clientWidth));
    const left=currentPage*stride;
    const transform=`translate3d(${-left}px,0,0)`;
    v.dataset.page=String(currentPage);
    /* Programmatic horizontal positioning is used for the live book stage. The
       viewport remains overflow-x:hidden, so the reader can never become a
       horizontally draggable/scrolled document. The curl itself remains the
       visible page-turn animation. This avoids compositor/theme transforms
       affecting the live text layout. */
    v.style.setProperty('scroll-behavior','auto','important');
    stage.style.setProperty('--paged-stage-transform','translate3d(0,0,0)','important');
    stage.style.setProperty('transform','none','important');
    stage.style.setProperty('-webkit-transform','none','important');
    if(behavior==='instant')stage.style.setProperty('transition','none','important');
    v.scrollLeft=left;
    currentStart=left;
    updateReaderUI();
  }
  function scrollToPage(page){
    if(settings.readerMode!=='paged')return;
    const v=$('#readerViewport'),stage=$('.reader-page-stage',v||document),a=$('.reader-article',stage||document);
    if(!v||!stage||!a)return;
    currentPage=clamp(Number(page)||0,0,pageMetrics().count-1);
    applyPageTransform('instant');
    restorePageAnnotation();
  }

  function makePageSnapshot(source, page, width, height, count, stride){
    const content=source.cloneNode(true);
    content.className='page-flip-content';
    content.removeAttribute('id');
    content.querySelectorAll('[id]').forEach(n=>n.removeAttribute('id'));
    content.querySelectorAll('canvas').forEach(n=>n.remove());
    const computed=getComputedStyle(source),gutter=Math.max(0,Number(source.dataset.pageGutter)||0),columnWidth=Math.max(1,width-2*gutter),columnGap=Math.max(0,2*gutter),contentWidth=Math.max(1,width*count);
    content.style.setProperty('--flip-content-width',`${contentWidth}px`);
    content.style.setProperty('--flip-content-height',`${height}px`);
    content.style.setProperty('--flip-page-width',`${columnWidth}px`);
    content.style.setProperty('--flip-column-count',String(count));
    Object.assign(content.style,{
      width:`${contentWidth}px`,height:`${height}px`,position:'absolute',left:'0px',top:'0px',margin:'0',
      padding:computed.padding||`32px ${gutter}px 46px`,boxSizing:'border-box',overflow:'visible',columnWidth:`${columnWidth}px`,columnCount:String(count),columnGap:`${columnGap}px`,columnFill:'auto',
      transform:`translate3d(${-page*stride}px,0,0)`,transformOrigin:'left top',color:computed.color,background:'transparent',backdropFilter:'none',
      fontFamily:computed.fontFamily,fontSize:computed.fontSize,lineHeight:computed.lineHeight,letterSpacing:computed.letterSpacing,fontWeight:computed.fontWeight,wordSpacing:computed.wordSpacing,textAlign:computed.textAlign,
      border:'0',borderRadius:'0',zIndex:'1',contain:'none'
    });
    content.style.setProperty('--flip-content-transform',`translate3d(${-page*stride}px,0,0)`,`important`);
    const snapFlow=content.querySelector('.reader-flow');
    if(snapFlow){snapFlow.style.setProperty('display','contents','important');snapFlow.style.setProperty('width','auto','important');snapFlow.style.setProperty('padding','0','important');}
    content.querySelectorAll('*').forEach(el=>{
      el.style.setProperty('color',computed.color,'important');
      el.style.setProperty('backdrop-filter','none','important');
      el.style.setProperty('-webkit-backdrop-filter','none','important');
    });
    content.querySelectorAll('img,svg,video').forEach(el=>el.style.setProperty('max-width','100%','important'));
    return content;
  }
  function animatePageTurn(dir,nextPage){
    if(settings.eink||window.matchMedia('(prefers-reduced-motion:reduce)').matches)return false;
    const v=$('#readerViewport'),source=$('.reader-article',v||document);if(!v||!source||settings.readerMode!=='paged')return false;
    $$('.page-flip',v).forEach(x=>x.remove());
    const width=Math.max(1,v.clientWidth),height=Math.max(1,v.clientHeight),count=Math.max(1,Number(source.dataset.pageCount||1)),stride=Math.max(1,Number(source.dataset.pageStride)||width),fromPage=currentPage,toPage=clamp(nextPage,0,count-1),token=++pageTurnToken;
    if(fromPage===toPage)return false;

    // Capture ONLY the page that is leaving. The real article is moved to the
    // destination immediately underneath it, eliminating any first-page flash
    // or delayed incoming-text reveal.
    const flip=document.createElement('div');flip.className=`page-flip ${dir>0?'next':'prev'}`;flip.dataset.from=String(fromPage);flip.dataset.to=String(toPage);
    const outgoing=document.createElement('div');outgoing.className='page-flip-sheet page-flip-outgoing';outgoing.style.transformOrigin=dir>0?'100% 50%':'0% 50%';
    const flipWindow=document.createElement('div');flipWindow.className='page-flip-window';
    flipWindow.appendChild(makePageSnapshot(source,fromPage,width,height,count,stride));
    outgoing.appendChild(flipWindow);
    flip.appendChild(outgoing);
    v.appendChild(flip);

    // Put the outgoing sheet in the compositor before moving the live article.
    // The destination page therefore cannot paint uncovered before the curl exists.
    scrollToPage(toPage);
    void flip.offsetWidth;
    requestAnimationFrame(()=>{if(token===pageTurnToken)flip.classList.add('active');});
    setTimeout(()=>{if(flip.isConnected)flip.remove();},760);
    return true;
  }
  function renderReader(){if(!current)return;stopTTS();annotationMode=false;activeStroke=null;document.querySelector('.reader-viewport')?._readerCleanup?.();const paged=settings.readerMode==='paged' && current.type!=='pdf';document.body.innerHTML=`<div class="reader-screen"><header class="reader-top"><button class="reader-back" id="back">‹ <span>Library</span></button><div class="reader-book"><b>${esc(current.title)}</b><small>${esc(current.chapters[currentChapter]?.title||'')}</small></div><div class="reader-tools"><button id="toc" aria-label="Table of contents">☷</button><button id="annotations" aria-label="Annotation tools">✎</button><button id="annotationList" aria-label="Saved annotations">☰</button><button id="bookmark" aria-label="Bookmark">${current.bookmarks?.some(x=>x.chapter===currentChapter&&(!paged||x.page===currentPage))?'★':'☆'}</button><button id="readerSearch" aria-label="Search">⌕</button><button id="translate" aria-label="Translate">文A</button><button id="tts" aria-label="Read aloud">▶</button><button id="readerSettings" aria-label="Settings">⚙</button></div></header><main class="reader-main"><div id="readerViewport" class="reader-viewport ${paged?'paged-mode':''} enter">${paged?'<div class="reader-page-underlay"></div>':''}${paged?'<div class="reader-page-stage">'+readerContent(current,currentChapter)+'</div>':readerContent(current,currentChapter)}<canvas id="inkCanvas" class="ink-canvas" aria-hidden="true"></canvas><div class="annotation-toolbar" id="annotationToolbar" hidden><button data-tool="pen" class="tool active">Pen</button><button data-tool="marker" class="tool">Marker</button><button data-tool="eraser" class="tool">Eraser</button><button data-tool="clear" class="tool danger">Clear</button><span class="ink-hint">Stylus writes · finger navigates</span></div></div></main><footer class="reader-bottom"><button id="prev" aria-label="Previous">←</button><div class="reader-progress"><span id="chapterLabel"></span><div><i id="readerBar"></i></div><small class="reading-clock" aria-live="polite"><span id="readingClock"></span><span class="clock-sep">·</span><span id="wallClock"></span></small></div><button id="next" aria-label="Next">→</button></footer></div>`;if(paged){const ra=$('.reader-article');const rf=$('.reader-flow',ra||document);if(ra&&rf){const frag=document.createDocumentFragment();while(rf.firstChild)frag.appendChild(rf.firstChild);rf.replaceWith(frag);}}$('#back').onclick=async()=>{stopTTS();await stopReadingTimer(true);await saveReaderState();books=await all();current=null;library();};$('#prev').onclick=()=>navigate(-1);$('#next').onclick=()=>navigate(1);$('#readerSettings').onclick=settingsUI;$('#readerSearch').onclick=readerSearch;$('#toc').onclick=tocUI;$('#annotations').onclick=toggleAnnotationTools;$('#translate').onclick=translateUI;$('#tts').onclick=toggleTTS;$('#bookmark').onclick=toggleBookmark;$('#annotationList').onclick=annotationsUI;const viewport=$('#readerViewport');viewport.addEventListener('click',e=>{const note=e.target.closest?.('mark.saved-note');if(note){const n=(current.notes||[]).find(x=>x.id===note.dataset.noteId);if(n){if(settings.readerMode==='scroll'){const target=note;target.scrollIntoView({block:'center',behavior:settings.eink?'auto':'smooth'});}else{currentPage=Number(n.page)||0;applyPageTransform('instant');}return;}}const a=e.target.closest?.('a');if(a){const href=a.getAttribute('href')||'';if(href.startsWith('#')){e.preventDefault();const id=href.slice(1);document.getElementById(id)?.scrollIntoView({block:'center',behavior:settings.eink?'auto':'smooth'});}else e.preventDefault();}});setupReaderPointers(viewport,$('#inkCanvas'));viewport.addEventListener('scroll',()=>{if(settings.readerMode==='scroll')saveScroll();},{passive:true});updateReaderUI();startReadingTimer();requestAnimationFrame(()=>{applySavedHighlights();applySavedNotes();layoutPagedReader(true);resizeInkCanvas();restorePageAnnotation();if(settings.readerMode==='scroll'){const v=$('#readerViewport');if(v){requestAnimationFrame(()=>{const max=Math.max(0,v.scrollHeight-v.clientHeight);v.scrollTop=clamp(currentStart,0,max);updateReaderUI();});}}if(pendingSearch){const q=pendingSearch;pendingSearch='';highlightSearch(q);}if(pendingAnnotationNav&&pendingAnnotationNav.chapter===currentChapter){const nav=pendingAnnotationNav;pendingAnnotationNav=null;setTimeout(()=>{const m=nav.noteId?$('.saved-note[data-note-id="'+CSS.escape(nav.noteId)+'"]'):null;if(m){if(settings.readerMode==='scroll')m.scrollIntoView({block:'center',behavior:settings.eink?'auto':'smooth'});else{currentPage=nav.page;applyPageTransform('silent');restorePageAnnotation();}}},60);}});const reflow=()=>{clearTimeout(pageReflowTimer);pageReflowTimer=requestAnimationFrame(()=>{layoutPagedReader(true);resizeInkCanvas();applyPageTransform('silent');restorePageAnnotation();});};window.addEventListener('resize',reflow,{passive:true});viewport._readerCleanup=()=>window.removeEventListener('resize',reflow);}
  function pageCount(){return pageMetrics().count||1;}
  function navigate(dir){if(!current)return;if(settings.readerMode==='paged'){const {count}=pageMetrics(),next=currentPage+dir;if(next>=0&&next<count){if(!animatePageTurn(dir,next)){scrollToPage(next);saveReaderState();}return;}if(dir>0&&currentChapter<current.chapters.length-1){changeChapter(1);return;}if(dir<0&&currentChapter>0){changeChapter(-1);return;}showToast(dir>0?'End of book.':'Beginning of book.');return;}changeChapter(dir);}
  let scrollSaveTimer=0;function saveScroll(){clearTimeout(scrollSaveTimer);scrollSaveTimer=setTimeout(()=>persistScrollState(),220);}async function persistScrollState(){const v=$('#readerViewport');if(!v||!current)return;const a=$('.reader-article',v),stride=Number(a?.dataset.pageStride)||v.clientWidth;currentStart=settings.readerMode==='paged'?currentPage*stride:v.scrollTop;const max=settings.readerMode==='paged'?Math.max(1,(pageCount()-1)*v.clientWidth):Math.max(1,v.scrollHeight-v.clientHeight),local=settings.readerMode==='paged'?clamp(currentPage/Math.max(1,pageCount()-1),0,1):clamp(v.scrollTop/max,0,1);current.progress=clamp((currentChapter+local)/Math.max(1,current.chapters.length),0,1);current.chapter=currentChapter;current.page=currentPage;current.scroll=currentStart;current.readingUpdated=Date.now();current.updated=Date.now();current.deviceUpdated={...(current.deviceUpdated||{}),[deviceId]:current.updated};current.history=[...(current.history||[]),{at:current.updated,chapter:currentChapter,page:currentPage,progress:current.progress}].slice(-100);await put(current);scheduleAutoSync();updateReaderUI();}
  function updateReaderUI(){const v=$('#readerViewport');if(!v||!current)return;const count=settings.readerMode==='paged'?pageMetrics().count:1;const local=settings.readerMode==='paged'?clamp(currentPage/Math.max(1,count-1),0,1):clamp(v.scrollTop/Math.max(1,v.scrollHeight-v.clientHeight),0,1);current.progress=clamp((currentChapter+local)/Math.max(1,current.chapters.length),0,1);$('#chapterLabel').textContent=settings.readerMode==='paged'?`Page ${currentPage+1} / ${count} · ${current.chapters[currentChapter]?.title||'Reading'} · ${Math.round(current.progress*100)}%`:`${currentChapter+1} / ${current.chapters.length} · ${current.chapters[currentChapter]?.title||'Reading'} · ${Math.round(current.progress*100)}%` ;$('#readerBar').style.width=`${Math.round(current.progress*100)}%`;if(current.progress>=.999&&!readingPaused&&readingStartedAt){stopReadingTimer(true);}updateReadingClock();const bm=$('#bookmark');if(bm)bm.textContent=current.bookmarks?.some(x=>x.chapter===currentChapter&&(settings.readerMode!=='paged'||x.page===currentPage))?'★':'☆';}
  async function saveReaderState(){if(!current)return;current.chapter=currentChapter;current.page=currentPage;current.scroll=currentStart;current.minutes=Math.floor((current.readingSeconds||0)/60);current.readingUpdated=Date.now();current.updated=Date.now();current.deviceUpdated={...(current.deviceUpdated||{}),[deviceId]:current.updated};await put(current);scheduleAutoSync();updateReadingClock();}
  async function changeChapter(dir){if(!current)return;const target=currentChapter+dir;if(target<0||target>=current.chapters.length){showToast(dir>0?'End of book.':'Beginning of book.');return;}await saveReaderState();currentChapter=target;current.chapter=target;currentPage=dir>0?0:999999;currentStart=0;renderReader();}

  function markTextRange(article,startOffset,length,cls,attrs={}){
    if(!article||!Number.isFinite(startOffset)||!length)return false;
    const walker=document.createTreeWalker(article,NodeFilter.SHOW_TEXT);
    const nodes=[]; let total=0,n;
    while(n=walker.nextNode()){const value=n.nodeValue||'',begin=total,end=total+value.length;if(end>startOffset&&begin<startOffset+length)nodes.push({node:n,begin,end});total=end;}
    if(!nodes.length)return false;
    const endOffset=startOffset+length;
    for(let i=nodes.length-1;i>=0;i--){const {node,begin,end}=nodes[i],lo=Math.max(startOffset,begin)-begin,hi=Math.min(endOffset,end)-begin;if(hi<=lo)continue;const parent=node.parentElement;if(parent?.closest?.('mark.saved-note,mark.saved-highlight'))continue;const r=document.createRange();r.setStart(node,lo);r.setEnd(node,hi);const mark=document.createElement('mark');mark.className=cls;Object.entries(attrs).forEach(([k,v])=>mark.dataset[k]=String(v));try{r.surroundContents(mark);}catch{const f=r.extractContents();mark.appendChild(f);r.insertNode(mark);}}
    return true;
  }
  function markPhrase(article,q,cls,attrs={}){const query=(q||'').trim();if(!article||!query)return null;const snap=textNodesSnapshot(article),needle=query.toLocaleLowerCase(),text=snap.full.toLocaleLowerCase(),idx=text.indexOf(needle);if(idx<0)return null;return markTextRange(article,idx,query.length,cls,attrs)?$('.saved-note,.saved-highlight',article):null;}
  function rangeStartOffset(article,range){const walker=document.createTreeWalker(article,NodeFilter.SHOW_TEXT);let total=0,node;while(node=walker.nextNode()){if(node===range.startContainer)return total+range.startOffset;total+=(node.nodeValue||'').length;}return null;}
  function applySavedHighlights(){const article=$('.reader-article');if(!article)return;for(const h of (current?.highlights||[]).filter(x=>x.chapter===currentChapter).slice(0,100)){if(Number.isFinite(h.startOffset)&&markTextRange(article,h.startOffset,(h.text||'').length,'saved-highlight'))continue;markPhrase(article,h.text,'saved-highlight');}}
  function applySavedNotes(){const article=$('.reader-article');if(!article)return;for(const n of (current?.notes||[]).filter(x=>x.chapter===currentChapter).slice(0,100)){const len=(n.text||'').length;let ok=false;if(Number.isFinite(n.startOffset)&&len)ok=markTextRange(article,n.startOffset,len,'saved-note',{noteId:n.id});if(!ok){const mark=markPhrase(article,n.text,'saved-note',{noteId:n.id});if(mark)mark.title=n.note||'Note';}}}

  let ttsSession=0,ttsSegments=[],ttsIndex=0,ttsPaused=false,ttsNativeCurrent=null;
  const nativeTTS=()=>globalThis.AndroidTTS&&typeof AndroidTTS.speak==='function'&&(!AndroidTTS.isReady||AndroidTTS.isReady());
  function speechLanguage(text){return /[ğüşöçıİıĞÜŞÖÇ]/.test(text)?'tr':'en';}
  function voiceScore(v,lang){const n=(v.name||'').toLowerCase(),l=(v.lang||'').toLowerCase();if(!l.startsWith(lang))return -1e4;let s=50;if(v.localService===false)s+=8;if(/natural|neural|premium|enhanced|online|studio|wavenet/.test(n))s+=38;if(/google|microsoft|samsung|apple/.test(n))s+=15;if(/espeak|festival|robot|compact/.test(n))s-=35;return s;}
  function availableVoices(){return 'speechSynthesis'in window?(speechSynthesis.getVoices?.()||[]):[];}
  function chooseTTSVoice(){const voices=availableVoices(),lang=speechLanguage(current?.chapters?.[currentChapter]?.html||'');if(settings.ttsVoice){const exact=voices.find(v=>v.name===settings.ttsVoice);if(exact&&voiceScore(exact,lang)>=70)return exact;}return voices.filter(v=>v.lang?.toLowerCase().startsWith(lang)).sort((a,b)=>voiceScore(b,lang)-voiceScore(a,lang))[0]||voices[0]||null;}
    function scenePace(text){const t=(text||'').toLocaleLowerCase();const action=/(attack|fight|run|running|chase|gun|shot|shoot|blood|kill|scream|shout|explod|crash|slam|sudden|suddenly|escape|strike|hit|battle|kaç|koş|kovala|silah|ateş|vur|kan|savaş|bağır|patla|çarp|kaçış)/.test(t);const calm=/(quiet|silence|silent|peaceful|calm|gently|softly|slowly|warm|rest|sleep|dream|breeze|rain|morning|evening|peace|sakince|sessiz|huzur|yavaşça|usulca|ılık|dinlen|uyku|rüya|esinti|yağmur|sabah|akşam)/.test(t);const dramatic=/(!|\?|however|but|yet|finally|ama|fakat|ancak|birden|sonunda)/.test(t);let energy=action?.90:calm?.16:dramatic?.68:.46;if(text.length>190)energy+=Math.min(.18,(text.length-190)/900);return clamp(energy,0,1);}
  function chapterSpeechSegments(){const d=document.createElement('div');d.innerHTML=current?.chapters?.[currentChapter]?.html||'';const blocks=[...d.querySelectorAll('h1,h2,h3,h4,p,li,blockquote,figcaption,dt,dd')],raw=blocks.length?blocks.map(x=>x.textContent.trim()).filter(Boolean):[d.textContent||''];const seg=[];for(const block of raw){const parts=block.match(/[^.!?。！？]+[.!?。！？]+|[^.!?。！？]+$/g)||[block];for(const part of parts){const text=part.trim();if(!text)continue;const style=scenePace(text);seg.push({text,isDialogue:/[“”"]/.test(text)||/(^|\s)[—–-]\s/.test(text),pause:/[.!?。！？]$/.test(text),energy:style});}}return seg;}
  function removeTTSPanel(){ttsPanelEl?.remove();ttsPanelEl=null;}
  function stopTTS(){ttsSession++;ttsSegments=[];ttsIndex=0;ttsPaused=false;ttsNativeCurrent=null;if(nativeTTS())try{AndroidTTS.stop();}catch{}if('speechSynthesis'in window){speechSynthesis.cancel();speechSynthesis.resume?.();}removeTTSPanel();const b=$('#tts');if(b)b.textContent='▶';}
  function renderTTSPanel(){if(ttsPanelEl)ttsPanelEl.remove();const voices=availableVoices();const native=nativeTTS()&&!('speechSynthesis'in window);ttsPanelEl=document.createElement('div');ttsPanelEl.className='tts-panel enter';ttsPanelEl.innerHTML=`<div><small>READ ALOUD</small><b>${native?'System voice · adaptive story pacing':'Adaptive story pacing'}</b></div>${native?'':'<select id="ttsVoice" class="field"><option value="">Best available natural voice</option>'+voices.map(v=>`<option value="${esc(v.name)}">${esc(v.name)} · ${esc(v.lang)}</option>`).join('')+'</select>'}<select id="ttsSpeed" class="field"><option value="0.84">0.84× · Leisurely</option><option value="0.90">0.90× · Story</option><option value="0.96">0.96× · Natural</option><option value="1.02">1.02× · Lively</option></select><button id="ttsPause" class="text-btn">Pause</button><button id="ttsStop" class="close">×</button>`;document.querySelector('.reader-screen')?.appendChild(ttsPanelEl);if(!native){$('#ttsVoice',ttsPanelEl).value=settings.ttsVoice||'';$('#ttsVoice',ttsPanelEl).onchange=e=>{settings.ttsVoice=e.target.value;applySettings();restartTTSSegment();};}$('#ttsSpeed',ttsPanelEl).value=String(settings.ttsRate||.96);$('#ttsSpeed',ttsPanelEl).onchange=e=>{settings.ttsRate=+e.target.value;applySettings();restartTTSSegment();};$('#ttsPause',ttsPanelEl).onclick=()=>{if(nativeTTS()&&!('speechSynthesis'in window)){if(ttsPaused){ttsPaused=false;speakNativeNext(ttsSession);}else{ttsPaused=true;try{AndroidTTS.stop();}catch{}}$('#ttsPause',ttsPanelEl).textContent=ttsPaused?'Resume':'Pause';}else{if(speechSynthesis.paused){speechSynthesis.resume();ttsPaused=false;$('#ttsPause',ttsPanelEl).textContent='Pause';}else{speechSynthesis.pause();ttsPaused=true;$('#ttsPause',ttsPanelEl).textContent='Resume';}}};$('#ttsStop',ttsPanelEl).onclick=stopTTS;}
  function restartTTSSegment(){if(!ttsSegments.length)return;ttsIndex=Math.max(0,ttsIndex-1);if(nativeTTS()&&!('speechSynthesis'in window)){try{AndroidTTS.stop();}catch{}setTimeout(()=>speakNativeNext(ttsSession),40);return;}if('speechSynthesis'in window){speechSynthesis.cancel();setTimeout(()=>speakNext(ttsSession),40);}}
  function speakNativeNext(session){if(session!==ttsSession||ttsPaused)return;if(ttsIndex>=ttsSegments.length){showToast('Finished reading aloud.');stopTTS();return;}const seg=ttsSegments[ttsIndex++];ttsNativeCurrent=seg.text;const rate=clamp((settings.ttsRate||.96)*(.84+(seg.energy??.46)*.31)*(seg.isDialogue?.94:1),.68,1.12);const lang=speechLanguage(seg.text);try{AndroidTTS.speak(seg.text,rate,1,lang,String(session));}catch{showToast('Android text-to-speech could not start.',true);stopTTS();}}
  window.__prNativeTtsDone=function(id){const session=Number(id);if(session!==ttsSession||ttsPaused)return;const seg=ttsSegments[ttsIndex-1]||{};const pause=(seg.pause?220:70)+Math.round((1-(seg.energy??.46))*280)+(seg.isDialogue?80:0);setTimeout(()=>speakNativeNext(session),pause);};
  function speakNext(session){if(session!==ttsSession||!('speechSynthesis'in window))return;if(ttsIndex>=ttsSegments.length){showToast('Finished reading aloud.');stopTTS();return;}const seg=ttsSegments[ttsIndex++],u=new SpeechSynthesisUtterance(seg.text),voice=chooseTTSVoice(),base=clamp(settings.ttsRate||.96,.78,1.05),energy=seg.energy??.46;u.voice=voice||null;u.lang=voice?.lang||undefined;u.rate=clamp(base*(.84+energy*.31)*(seg.isDialogue?.94:1),.68,1.12);u.pitch=1;u.volume=1;u.onend=()=>{if(session!==ttsSession)return;const pause=(seg.pause?220:70)+Math.round((1-energy)*280)+(seg.isDialogue?80:0);setTimeout(()=>speakNext(session),pause);};u.onerror=()=>{if(session===ttsSession){showToast('The selected speech voice could not continue. Choose another voice.',true);stopTTS();}};speechSynthesis.resume?.();speechSynthesis.speak(u);}
  function toggleTTS(){const native=nativeTTS()&&!('speechSynthesis'in window);if(!native&&globalThis.AndroidTTS&&typeof AndroidTTS.isReady==='function'&&!AndroidTTS.isReady()&&!('speechSynthesis'in window)){showToast('Android text-to-speech is still starting. Please try again in a moment.',true);return;}const web='speechSynthesis'in window;if(!native&&!web){showToast('Text-to-speech is not available on this device.',true);return;}if(native?ttsSegments.length>0:(speechSynthesis.speaking||speechSynthesis.paused||ttsSegments.length)){stopTTS();showToast('Reading aloud stopped.');return;}const segments=chapterSpeechSegments();if(!segments.length){showToast('This chapter has no readable text.',true);return;}ttsSession++;ttsSegments=segments;ttsIndex=0;renderTTSPanel();$('#tts').textContent='■';if(native)speakNativeNext(ttsSession);else{const start=()=>speakNext(ttsSession);if(availableVoices().length)start();else{speechSynthesis.onvoiceschanged=()=>{speechSynthesis.onvoiceschanged=null;start();};setTimeout(start,250);}}showToast('Adaptive read-aloud started.');}

  function annotationStore(){current.pageAnnotations=current.pageAnnotations||[];return current.pageAnnotations;}
  function annotationPageKey(){const v=$('#readerViewport');return `${currentChapter}:${settings.readerMode==='paged'?currentPage:Math.max(0,Math.floor((v?.scrollTop||0)/Math.max(1,v?.clientHeight||1)))}`;}
  function getPageStrokes(){const key=annotationPageKey();return annotationStore().filter(x=>x.key===key);}
  let annotationMode=false,activeTool='pen',activeStroke=null,strokeDirty=false;
  function resizeInkCanvas(){const v=$('#readerViewport'),c=$('#inkCanvas');if(!v||!c)return;const dpr=Math.max(1,Math.min(3,window.devicePixelRatio||1));c.width=Math.round(v.clientWidth*dpr);c.height=Math.round(v.clientHeight*dpr);c.style.width=`${v.clientWidth}px`;c.style.height=`${v.clientHeight}px`;const ctx=c.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);restorePageAnnotation();}
  function strokeStyle(tool){if(tool==='marker')return{width:Math.max(18,Math.round(settings.font*1.08)),color:'rgba(255,220,75,.32)',composite:'source-over'};if(tool==='eraser')return{width:30,color:'rgba(0,0,0,1)',composite:'destination-out'};return{width:4,color:getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()||'#8ab4ff',composite:'source-over'};}
  function drawStroke(ctx,s){if(!s.points?.length)return;const c=ctx.canvas,style=strokeStyle(s.tool);ctx.save();ctx.beginPath();ctx.lineCap='round';ctx.lineJoin='round';ctx.lineWidth=s.width||style.width;ctx.globalCompositeOperation=style.composite;ctx.strokeStyle=s.color||style.color;const pts=s.points;if(pts.length===1){const p=pts[0],x=(p.nx??p.x)*c.clientWidth,y=(p.ny??p.y)*c.clientHeight;ctx.fillStyle=s.color||style.color;ctx.arc(x,y,Math.max(1,(s.width||style.width)/2),0,Math.PI*2);ctx.fill();}else{pts.forEach((p,i)=>{const x=(p.nx??p.x)*c.clientWidth,y=(p.ny??p.y)*c.clientHeight;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.stroke();}ctx.restore();}
  function restorePageAnnotation(){const c=$('#inkCanvas'),v=$('#readerViewport');if(!c||!v)return;const ctx=c.getContext('2d');ctx.clearRect(0,0,v.clientWidth,v.clientHeight);getPageStrokes().forEach(s=>drawStroke(ctx,s));}
  function toggleAnnotationTools(){if(settings.readerMode!=='paged'){settings.readerMode='paged';currentPage=0;currentStart=0;applySettings();renderReader();setTimeout(()=>{annotationMode=true;$('#annotationToolbar').hidden=false;$('#readerViewport').classList.add('annotation-active');resizeInkCanvas();},80);showToast('Precise annotation uses page mode.');return;}annotationMode=!annotationMode;const bar=$('#annotationToolbar'),v=$('#readerViewport');if(bar)bar.hidden=!annotationMode;if(v)v.classList.toggle('annotation-active',annotationMode);if(annotationMode)resizeInkCanvas();}
  function setAnnotationTool(tool){activeTool=tool;settings.annotationTool=tool;applySettings();if(tool==='clear'){const key=annotationPageKey();current.pageAnnotations=(current.pageAnnotations||[]).filter(s=>s.key!==key);activeTool='pen';settings.annotationTool='pen';$$('#annotationToolbar .tool').forEach(b=>b.classList.toggle('active',b.dataset.tool==='pen'));put(current).then(()=>restorePageAnnotation());showToast('Ink cleared from this page.');return;}$$('#annotationToolbar .tool').forEach(b=>b.classList.toggle('active',b.dataset.tool===tool));}
  function pointFromEvent(e){const r=$('#inkCanvas').getBoundingClientRect();const x=clamp(e.clientX-r.left,0,r.width),y=clamp(e.clientY-r.top,0,r.height);return{nx:r.width?x/r.width:0,ny:r.height?y/r.height:0};}
  function beginInk(e){if(e.pointerType!=='pen'||!annotationMode)return;const style=strokeStyle(activeTool);activeStroke={id:uid(),key:annotationPageKey(),chapter:currentChapter,page:currentPage,tool:activeTool,width:style.width,color:style.color,points:[pointFromEvent(e)],created:Date.now()};strokeDirty=false;try{$('#inkCanvas').setPointerCapture?.(e.pointerId);}catch{}e.preventDefault();drawStroke($('#inkCanvas').getContext('2d'),activeStroke);}
  function moveInk(e){if(!activeStroke||e.pointerType!=='pen')return;activeStroke.points.push(pointFromEvent(e));strokeDirty=true;drawStroke($('#inkCanvas').getContext('2d'),activeStroke);e.preventDefault();}
  function endInk(e){if(!activeStroke)return;current.pageAnnotations=current.pageAnnotations||[];if(strokeDirty||activeStroke.points.length>1)current.pageAnnotations.push(activeStroke);activeStroke=null;put(current).then(()=>scheduleAutoSync());e.preventDefault();}
  function setupReaderPointers(v,c){let sx=0,sy=0,sxTime=0,activePointer=null;v.addEventListener('pointerdown',e=>{if(e.target.closest?.('.annotation-toolbar'))return;if(e.pointerType==='pen'){if(settings.penAuto&&!annotationMode){annotationMode=true;$('#annotationToolbar').hidden=false;v.classList.add('annotation-active');activeTool='pen';$$('#annotationToolbar .tool').forEach(b=>b.classList.toggle('active',b.dataset.tool==='pen'));resizeInkCanvas();}if(annotationMode){activePointer='pen';beginInk(e);return;}}if(e.pointerType==='touch'){if(annotationMode&&settings.annotationInput==='both'){activePointer='touch';beginInk({...e,pointerType:'pen'});return;}activePointer='touch';sx=e.clientX;sy=e.clientY;sxTime=performance.now();}},{passive:false});v.addEventListener('pointermove',e=>{if(activePointer==='pen'&&e.pointerType==='pen')moveInk(e);else if(activePointer==='touch'&&e.pointerType==='touch'&&annotationMode&&settings.annotationInput==='both')moveInk({...e,pointerType:'pen'});},{passive:false});v.addEventListener('pointerup',e=>{if(activePointer==='pen'&&e.pointerType==='pen'){endInk(e);activePointer=null;return;}if(activePointer==='touch'&&e.pointerType==='touch'){if(annotationMode&&settings.annotationInput==='both'){endInk({...e,pointerType:'pen'});activePointer=null;return;}const dx=e.clientX-sx,dy=e.clientY-sy,dt=performance.now()-sxTime;activePointer=null;if(Math.abs(dx)>42&&Math.abs(dx)>Math.abs(dy)*1.18&&dt<900){e.preventDefault();navigate(dx<0?1:-1);}}},{passive:false});v.addEventListener('pointercancel',e=>{if((activePointer==='pen'||activePointer==='touch')&&activeStroke)endInk({...e,pointerType:'pen'});activePointer=null;},{passive:false});v.addEventListener('contextmenu',e=>selectionMenu(e));$$('#annotationToolbar .tool').forEach(b=>b.onclick=()=>setAnnotationTool(b.dataset.tool));}
  function notesUI(){
    const allItems=[];
    for(const b of books){
      for(const n of (b.notes||[])) allItems.push({kind:'Note',book:b,chapter:Number(n.chapter)||0,page:Number(n.page)||0,text:n.text||'',note:n.note||'',id:n.id,created:n.created||0});
      for(const h of (b.highlights||[])) allItems.push({kind:'Highlight',book:b,chapter:Number(h.chapter)||0,page:Number(h.page)||0,text:h.text||'',note:'',id:h.id||uid(),created:h.created||0});
    }
    allItems.sort((a,b)=>b.created-a.created);
    const o=overlay(`<div class="modal-head"><div><div class="eyebrow">LIBRARY ANNOTATIONS</div><h2>Notes & highlights</h2></div><button class="close" aria-label="Close">×</button></div><input class="search-input" id="notesSearch" placeholder="Search your notes and highlights…"><div class="search-results" id="notesResults"></div>`);
    $('.close',o).onclick=()=>o.remove();
    const input=$('#notesSearch',o),results=$('#notesResults',o);
    const render=()=>{
      const q=input.value.trim().toLocaleLowerCase();
      const list=allItems.filter(x=>!q||`${x.book.title} ${x.book.author} ${x.text} ${x.note}`.toLocaleLowerCase().includes(q)).slice(0,150);
      results.innerHTML=list.length?list.map(x=>`<button class="annotation-item" data-note-book="${esc(x.book.id)}" data-note-chapter="${x.chapter}" data-note-page="${x.page}" data-note-id="${esc(x.id)}"><small>${esc(x.kind)} · ${esc(x.book.title)} · ${esc(x.book.chapters?.[x.chapter]?.title||`Chapter ${x.chapter+1}`)}</small><span>${esc(x.note||x.text||'Untitled annotation')}</span><i>Open →</i></button>`).join(''):'<p class="muted">No annotations found.</p>';
      $$('[data-note-book]',o).forEach(btn=>btn.onclick=()=>{const b=books.find(y=>y.id===btn.dataset.noteBook);if(!b)return;o.remove();current=b;currentChapter=clamp(Number(btn.dataset.noteChapter)||0,0,Math.max(0,b.chapters.length-1));currentPage=Number(btn.dataset.notePage)||0;currentStart=0;pendingAnnotationNav={chapter:currentChapter,page:currentPage,noteId:btn.dataset.noteId};localStorage.setItem('PersonalReaderLastBook',b.id);renderReader();});
    };
    input.oninput=render;render();setTimeout(()=>input.focus(),50);
  }

  function annotationsUI(){const hs=(current.highlights||[]).filter(x=>x.chapter===currentChapter),ns=(current.notes||[]).filter(x=>x.chapter===currentChapter),bs=(current.bookmarks||[]).filter(x=>x.chapter===currentChapter),ink=annotationStore().filter(x=>x.chapter===currentChapter);const items=[...bs.map(x=>({type:'Bookmark',text:x.title||`Page ${((x.page||0)+1)}`,page:x.page||0,anchor:x.position||0})),...hs.map(x=>({type:'Highlight',text:x.text,page:x.page||0,startOffset:x.startOffset})),...ns.map(x=>({type:'Note',text:x.note||x.text,page:x.page||0,startOffset:x.startOffset,noteId:x.id,quote:x.text}))];const o=overlay(`<div class="modal-head"><div><div class="eyebrow">ANNOTATIONS</div><h2>Notes, highlights & ink</h2></div><button class="close">×</button></div><div class="annotation-actions"><button class="cta" id="drawNow">Draw on this page <span>✎</span></button></div><div class="annotation-list">${items.map(x=>`<button class="annotation-item" data-anno-type="${esc(x.type)}" data-page="${x.page}" data-offset="${Number.isFinite(x.startOffset)?x.startOffset:''}" data-note-id="${esc(x.noteId||'')}"><small>${esc(x.type)}</small><span>${esc(x.text||'')}</span><i>Open →</i></button>`).join('')||'<p class="muted">Nothing saved in this chapter yet.</p>'}</div></div>`);$('.close',o).onclick=()=>o.remove();$('#drawNow',o).onclick=()=>{o.remove();annotationMode=true;$('#annotationToolbar').hidden=false;$('#readerViewport').classList.add('annotation-active');resizeInkCanvas();};$$('[data-anno-type]',o).forEach(x=>x.onclick=()=>{const page=Number(x.dataset.page)||0,offset=x.dataset.offset===''?null:Number(x.dataset.offset);o.remove();currentPage=page;currentStart=page*($('#readerViewport')?.clientWidth||1);pendingAnnotationNav={chapter:currentChapter,page,offset,noteId:x.dataset.noteId};renderReader();});}

  function tocUI(){const o=overlay(`<div class="modal-head"><div><div class="eyebrow">NAVIGATION</div><h2>Table of contents</h2></div><button class="close">×</button></div><div class="toc-list">${current.chapters.map((c,i)=>`<button data-ch="${i}" class="toc-item ${i===currentChapter?'active':''}"><span>${String(i+1).padStart(2,'0')}</span><b>${esc(c.title)}</b><i>${i===currentChapter?'Now reading':'→'}</i></button>`).join('')}</div>`);$('.close',o).onclick=()=>o.remove();$$('[data-ch]',o).forEach(x=>x.onclick=()=>{o.remove();currentChapter=+x.dataset.ch;currentPage=0;currentStart=0;renderReader();});}
  async function toggleBookmark(){if(!current)return;current.bookmarks=current.bookmarks||[];const i=current.bookmarks.findIndex(x=>x.chapter===currentChapter&&(settings.readerMode!=='paged'||x.page===currentPage));if(i>=0){current.bookmarks.splice(i,1);showToast('Bookmark removed.');}else{current.bookmarks.push({id:uid(),chapter:currentChapter,page:currentPage,position:currentStart,title:current.chapters[currentChapter].title,created:Date.now()});showToast('Bookmark saved.');}await put(current);updateReaderUI();}
  function selectionMenu(e){const sel=window.getSelection();const text=sel?.toString().trim();if(!text||!current)return;e.preventDefault();const article=$('.reader-article'),range=sel.getRangeAt(0),startOffset=article?rangeStartOffset(article,range):null;const o=overlay(`<div class="modal-head"><div><div class="eyebrow">SELECTION</div><h2>Save this passage</h2></div><button class="close">×</button></div><p class="selection-preview">“${esc(text.slice(0,500))}${text.length>500?'…':''}”</p><div class="menu-actions"><button id="highlight">Highlight <span>✦</span></button><button id="note">Add note <span>✎</span></button><button id="copy">Copy <span>↗</span></button></div>`);$('.close',o).onclick=()=>o.remove();$('#copy',o).onclick=async()=>{try{await navigator.clipboard?.writeText(text);}catch{}o.remove();showToast('Copied.');};$('#highlight',o).onclick=async()=>{current.highlights=current.highlights||[];current.highlights.push({id:uid(),chapter:currentChapter,page:currentPage,text,startOffset,created:Date.now()});await put(current);o.remove();applySavedHighlights();showToast('Highlight saved.');};$('#note',o).onclick=()=>{o.remove();noteForSelection(text,startOffset);};}
  async function noteForSelection(text,startOffset=null){const o=overlay(`<div class="modal-head"><div><div class="eyebrow">NOTE</div><h2>Add a note</h2></div><button class="close">×</button></div><p class="selection-preview">“${esc(text.slice(0,500))}${text.length>500?'…':''}”</p><textarea class="field note-editor" id="noteText" placeholder="Write your note…"></textarea><div class="modal-foot"><button class="text-btn close2">Cancel</button><button class="cta" id="saveNote">Add note <span>✓</span></button></div>`);$('.close',o).onclick=()=>o.remove();$('.close2',o).onclick=()=>o.remove();$('#saveNote',o).onclick=async()=>{const note=$('#noteText',o).value.trim();if(!note){showToast('Write something first.',true);return;}current.notes=current.notes||[];current.notes.push({id:uid(),chapter:currentChapter,page:currentPage,text,note,startOffset,created:Date.now()});await put(current);o.remove();renderReader();showToast('Note saved.');};setTimeout(()=>$('#noteText',o)?.focus(),40);}

  function translateUI(){const source=strip(current.chapters[currentChapter].html);const o=overlay(`<div class="modal-head"><div><div class="eyebrow">TRANSLATION</div><h2>Translate chapter</h2></div><button class="close">×</button></div><label class="label">Target language<select class="field" id="targetLang"><option>English</option><option>Turkish</option><option>German</option><option>French</option><option>Spanish</option><option>Italian</option><option>Japanese</option><option>Chinese</option><option>Korean</option><option>Russian</option><option>Arabic</option></select></label><button class="cta" id="runTranslate">Translate <span>→</span></button><div id="translationOut" class="translation-out"></div>`);$('.close',o).onclick=()=>o.remove();$('#runTranslate',o).onclick=()=>runTranslation(source,$('#targetLang',o).value,o);}
  async function runTranslation(source,target,o){const out=$('#translationOut',o);if(!settings.aiEndpoint){out.innerHTML='<p class="error-text">Translation is not configured. Open Settings → Translation and add a compatible endpoint and key.</p>';return;}out.innerHTML='<div class="loading-line"><span class="spinner"></span> Preserving tone, context and meaning…</div>';const prompt=`Translate the following ebook chapter into ${target}. Preserve meaning, literary voice, tone, names, paragraph structure, dialogue, and formatting as naturally as possible. Correct context-sensitive mistranslations rather than translating word-for-word. Return only the translation.\n\n${source.slice(0,90000)}`;try{const r=await fetch(settings.aiEndpoint,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${settings.aiKey}`},body:JSON.stringify({model:settings.aiModel||'gpt-4.1-mini',messages:[{role:'system',content:'You are a literary translator. Preserve authorial voice and context.'},{role:'user',content:prompt}],temperature:.2})});if(!r.ok)throw new Error(`Translation service returned ${r.status}`);const data=await r.json();const text=data.choices?.[0]?.message?.content||data.output_text||data.output?.[0]?.content?.[0]?.text;if(!text)throw new Error('The response did not contain translation text.');out.innerHTML=`<div class="translation-result">${esc(text).replace(/\n/g,'<br><br>')}</div><button class="text-btn" id="copyTranslation">Copy translation</button>`;$('#copyTranslation',o).onclick=()=>navigator.clipboard?.writeText(text);}catch(e){out.innerHTML=`<p class="error-text">Translation failed: ${esc(e.message)}</p>`;}}
  function readerSearch(){const o=overlay(`<div class="modal-head"><div><div class="eyebrow">IN THIS BOOK</div><h2>Search</h2></div><button class="close" aria-label="Close">×</button></div><input class="search-input" id="bookSearch" placeholder="Search this book…"><div id="bookResults" class="search-results"></div>`);$('.close',o).onclick=()=>o.remove();const input=$('#bookSearch',o),render=()=>{const q=input.value.trim();if(!q){$('#bookResults',o).innerHTML='<p class="muted">Type a word or phrase.</p>';return;}const results=[];current.chapters.forEach((c,i)=>{const text=strip(c.html),lower=text.toLocaleLowerCase(),needle=q.toLocaleLowerCase();let from=0,count=0;while((from=lower.indexOf(needle,from))>=0&&count<12){results.push({i,title:c.title,snippet:text.slice(Math.max(0,from-90),Math.min(text.length,from+q.length+140)),occurrence:count+1});from+=Math.max(1,needle.length);count++;}});$('#bookResults',o).innerHTML=results.map(r=>{const safe=esc(r.snippet),needle=esc(q),marked=safe.replace(new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'ig'),m=>`<mark class="search-hit">${m}</mark>`);return `<button class="search-result" data-ch="${r.i}" data-q="${esc(q)}"><span><b>${esc(r.title)}</b><small>…${marked}…</small></span><b>#${r.occurrence} →</b></button>`;}).join('')||'<p class="muted">No matches.</p>';$$('[data-ch]',o).forEach(x=>x.onclick=()=>{pendingSearch=x.dataset.q;o.remove();currentChapter=+x.dataset.ch;currentPage=0;currentStart=0;renderReader();});};input.oninput=render;render();setTimeout(()=>input.focus(),60);}
  function overlay(inner){const o=document.createElement('div');o.className='overlay';o.dataset.overlay='true';o.setAttribute('role','dialog');o.innerHTML=`<div class="modal">${inner}</div>`;document.body.appendChild(o);requestAnimationFrame(()=>o.classList.add('open'));o.addEventListener('click',e=>{if(e.target===o)o.remove();});return o;}
  document.addEventListener('click',e=>{const settingsBtn=e.target?.closest?.('#settingsBtn');if(settingsBtn){e.preventDefault();e.stopPropagation();if(!document.querySelector('.overlay[data-settings-modal="true"]'))settingsUI();return;}const customBtn=e.target?.closest?.('#customTheme');if(!customBtn)return;e.preventDefault();e.stopImmediatePropagation();customThemeUI();},true);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){const overlays=$$('.overlay');const top=overlays[overlays.length-1];if(top){top.remove();return;} if(annotationMode){annotationMode=false;$('#annotationToolbar')?.setAttribute('hidden','');$('#readerViewport')?.classList.remove('annotation-active');}}});
  document.addEventListener('keydown',libraryShortcut);
  document.addEventListener('visibilitychange',async()=>{if(!current)return;if(document.hidden){readingPaused=true;await stopReadingTimer(true);}else if(document.querySelector('.reader-screen')&&current.progress<.999){readingPaused=false;startReadingTimer();}});
  window.addEventListener('pagehide',()=>{if(current&&readingStartedAt){const elapsed=Math.max(0,(Date.now()-readingStartedAt)/1000);current.readingSeconds=(current.readingSeconds||0)+Math.floor(elapsed);current.minutes=Math.floor(current.readingSeconds/60);readingStartedAt=0;try{localStorage.setItem('PersonalReaderTimeRecovery',JSON.stringify({id:current.id,readingSeconds:current.readingSeconds,at:Date.now()}));}catch{}}});

  window.addEventListener('error',e=>{console.error('PersonalReader runtime error',e.error||e.message);showToast('A reader error occurred. Your library is still stored locally.',true);});
  window.addEventListener('unhandledrejection',e=>{console.error('PersonalReader promise error',e.reason);showToast('An operation could not be completed. Please try again.',true);});

  async function boot(){try{await openDB();if(settings.theme==='custom'&&settings.customWallpaper){const source=await digestHex(settings.customWallpaper);if(source!==settings.customPaletteSource||!settings.customPalette){const pal=await deriveWallpaperPalette(settings.customWallpaper,settings.customTone);settings.customPalette=pal||null;settings.customPaletteSource=source;applySettings();}}books=(await all()).filter(b=>Array.isArray(b.chapters)&&b.chapters.length&&b.title);folders=await allFolders();app();scheduleAutoSync();}catch(e){document.body.innerHTML=`<main class="onboarding"><section class="onboarding-card"><div class="appmark">PR</div><h1>Storage unavailable.</h1><p>${esc(e.message)}</p><small>Open PersonalReader in a current Chromium-based browser.</small></section></main>`;}}
  function app(){applySettings();settings.setup?launchScreen():setup(); if(settings.setup && new URLSearchParams(location.search).get('action')==='import') setTimeout(()=>$('#import')?.click(),500);}
  boot();
})();
