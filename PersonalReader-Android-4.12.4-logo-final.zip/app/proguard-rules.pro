# PersonalReader currently ships without code shrinking. Keep this file for a
# future minified release once the Android bridge grows beyond the WebView shell.
