plugins {
    id("com.android.application")
}

android {
    namespace = "com.personalreader.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.personalreader.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 4124
        versionName = "4.12.4"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.17.0")
}
