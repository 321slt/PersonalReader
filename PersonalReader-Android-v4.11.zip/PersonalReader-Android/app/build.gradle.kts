plugins {
    id("com.android.application")
}

android {
    namespace = "com.personalreader.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.personalreader.app"
        minSdk = 26
        targetSdk = 37
        versionCode = 411
        versionName = "4.11.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.17.0")
}
